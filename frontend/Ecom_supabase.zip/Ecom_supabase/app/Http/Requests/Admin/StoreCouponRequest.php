<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreCouponRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $couponId = $this->route('coupon')?->id;
        $expiresAtRules = ['nullable', 'date', 'after_or_equal:today'];
        $startsAtRules = ['nullable', 'date'];

        if ($this->filled('starts_at')) {
            $expiresAtRules[] = 'after:starts_at';
        }
        if (!$couponId) {
            $startsAtRules[] = 'after_or_equal:today';
        }

        return [
            'code' => ['required', 'string', 'max:50', Rule::unique('coupons', 'code')->ignore($couponId)],
            'type' => ['required', Rule::in(['percentage', 'fixed'])],
            'value' => ['required', 'numeric', 'min:0'],
            'minimum_order_amount' => ['nullable', 'numeric', 'min:0'],
            'maximum_discount' => ['nullable', 'numeric', 'min:0'],
            'usage_limit' => ['nullable', 'integer', 'min:1'],
            'usage_limit_per_user' => ['nullable', 'integer', 'min:1'],
            'starts_at' => $startsAtRules,
            'expires_at' => $expiresAtRules,
            'status' => ['sometimes', 'boolean'],
        ];
    }
}
