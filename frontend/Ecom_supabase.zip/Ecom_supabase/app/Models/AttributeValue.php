<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AttributeValue extends Model
{
 use HasFactory;
 protected $fillable=['attribute_id','value','color_code'];
 public function attribute(){return $this->belongsTo(Attribute::class);}
 public function variants(){return $this->belongsToMany(ProductVariant::class,'variant_attribute_values','attribute_value_id','variant_id')->withTimestamps();}
 public function variantAttributeValues(){return $this->hasMany(VariantAttributeValue::class);}
}
