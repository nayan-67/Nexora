<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductImage extends Model
{
    use HasFactory;
    protected $fillable = ['product_id', 'image', 'sort_order', 'is_primary'];
    protected function casts(): array
    {
        return ['sort_order' => 'integer', 'is_primary' => 'boolean'];
    }
    public function product()
    {
        return $this->belongsTo(Product::class);
    }
    public function getImageUrlAttribute(): ?string
    {
        return \App\Support\Supabase::url($this->image);
    }
}
