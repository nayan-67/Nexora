<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CartItem extends Model
{
 use HasFactory;
 protected $fillable=['cart_id','product_id','variant_id','quantity','price'];
 protected function casts(): array{return ['quantity'=>'integer','price'=>'decimal:2'];}
 public function cart(){return $this->belongsTo(Cart::class);}
 public function product(){return $this->belongsTo(Product::class);}
 public function variant(){return $this->belongsTo(ProductVariant::class,'variant_id');}
}
