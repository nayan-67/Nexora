<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    use HasFactory;
    protected $fillable = ['order_id', 'product_id', 'variant_id', 'product_name', 'sku', 'variant_name', 'image', 'quantity', 'unit_price', 'discount', 'total_price'];
    protected function casts(): array
    {
        return ['quantity' => 'integer', 'unit_price' => 'decimal:2', 'discount' => 'decimal:2', 'total_price' => 'decimal:2'];
    }
    public function order()
    {
        return $this->belongsTo(Order::class);
    }
    public function product()
    {
        return $this->belongsTo(Product::class);
    }
    public function variant()
    {
        return $this->belongsTo(ProductVariant::class, 'variant_id');
    }
    public function getImageUrlAttribute(): ?string
    {
        return \App\Support\Supabase::url($this->image);
    }
}
