
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['status']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['status']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $map = [
        'Processing' => 'bg-amber-100 text-amber-700',
        'Shipped' => 'bg-sky-100 text-sky-700',
        'Delivered' => 'bg-emerald-100 text-emerald-700',
        'Cancelled' => 'bg-red-100 text-red-700',
        'Paid' => 'bg-emerald-100 text-emerald-700',
        'Pending' => 'bg-red-100 text-red-600',
        'Published' => 'bg-emerald-100 text-emerald-700',
        'Draft' => 'bg-amber-100 text-amber-700',
        'Active' => 'bg-emerald-100 text-emerald-700',
        'Inactive' => 'bg-red-100 text-red-600',
        'Blocked' => 'bg-red-100 text-red-600',
    ];
    $class = $map[$status] ?? 'bg-slate-100 text-slate-600';
?>
<span <?php echo e($attributes->merge(['class' => "text-[11.5px] font-semibold rounded-full px-2.5 py-1 $class"])); ?>>
    <?php echo e($status); ?>

</span>
<?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\admin\components\pill.blade.php ENDPATH**/ ?>