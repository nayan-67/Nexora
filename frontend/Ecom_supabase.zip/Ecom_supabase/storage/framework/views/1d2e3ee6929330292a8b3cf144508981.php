

<?php $__env->startSection('title', 'Addresses — AgriExpress'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-5xl mx-auto px-4 py-8">
        <div class="flex items-center gap-3 mb-6"><a href="<?php echo e(route('account')); ?>" class="text-gray-400 hover:text-gray-700"><i
                    class="fa-solid fa-arrow-left"></i></a>
            <h1 class="text-2xl font-bold text-gray-900">My Addresses</h1>
        </div>
        <?php if(session('status')): ?>
            <div class="mb-5 rounded-md bg-emerald-50 px-4 py-3 text-sm text-emerald-700"><?php echo e(session('status')); ?></div>
        <?php endif; ?>
        <div class="grid lg:grid-cols-[1fr_360px] gap-8">
            <div class="space-y-3">
                <?php $__empty_1 = true; $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="border border-gray-100 rounded-lg p-5 flex justify-between gap-4">
                        <div class="text-sm text-gray-600">
                            <p class="font-semibold text-gray-900 mb-1"><?php echo e(ucfirst($address->type)); ?> <?php if($address->is_default): ?>
                                    <span class="text-xs text-emerald-600">Default</span>
                                <?php endif; ?>
                            </p>
                            <p><?php echo e(trim($address->first_name . ' ' . $address->last_name)); ?></p>
                            <p><?php echo e($address->address_line_1); ?></p>
                            <p><?php echo e($address->city); ?>, <?php echo e($address->state); ?> <?php echo e($address->postal_code); ?></p>
                            <p><?php echo e($address->phone); ?></p>
                        </div>
                        <form action="<?php echo e(route('account.addresses.destroy', $address)); ?>" method="POST"><?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?><button class="text-gray-400 hover:text-red-500" title="Remove address"><i
                                    class="fa-regular fa-trash-can"></i></button></form>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="border border-dashed border-gray-200 rounded-lg p-10 text-center text-sm text-gray-500">No
                        saved addresses yet.</div>
                <?php endif; ?>
            </div>
            <form action="<?php echo e(route('account.addresses.store')); ?>" method="POST"
                class="border border-gray-100 rounded-lg p-5 space-y-3">
                <?php echo csrf_field(); ?>
                <h2 class="font-semibold text-gray-900">Add address</h2>
                <select name="type" class="w-full border border-gray-200 rounded-md px-3 py-2 text-sm">
                    <option value="home">Home</option>
                    <option value="office">Office</option>
                </select>
                <div class="grid grid-cols-2 gap-2"><input name="first_name" required placeholder="First name"
                        class="border border-gray-200 rounded-md px-3 py-2 text-sm"><input name="last_name"
                        placeholder="Last name" class="border border-gray-200 rounded-md px-3 py-2 text-sm"></div>
                <input name="phone" required placeholder="Phone"
                    class="w-full border border-gray-200 rounded-md px-3 py-2 text-sm"><input name="address_line_1" required
                    placeholder="Address" class="w-full border border-gray-200 rounded-md px-3 py-2 text-sm"><input
                    name="address_line_2" placeholder="Apartment, suite"
                    class="w-full border border-gray-200 rounded-md px-3 py-2 text-sm">
                <div class="grid grid-cols-2 gap-2"><input name="city" required placeholder="City"
                        class="border border-gray-200 rounded-md px-3 py-2 text-sm"><input name="state" required
                        placeholder="State" class="border border-gray-200 rounded-md px-3 py-2 text-sm"><input
                        name="postal_code" required placeholder="Postal code"
                        class="border border-gray-200 rounded-md px-3 py-2 text-sm"><input name="country" required
                        value="India" class="border border-gray-200 rounded-md px-3 py-2 text-sm"></div>
                <label class="flex items-center gap-2 text-sm text-gray-600"><input type="checkbox" name="is_default"
                        value="1"> Make default</label>
                <button class="w-full bg-brand-700 hover:bg-brand-800 text-white py-2.5 rounded-md text-sm font-medium">Save
                    address</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\user\addresses.blade.php ENDPATH**/ ?>