<?php $__env->startSection('title', 'AgriExpress — Discover Your New Favorites'); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        /* ---------- HERO ---------- */
        .se-hero {
            position: relative;
            overflow: hidden;
        }

        .se-hero__track {
            display: flex;
            transition: transform .5s ease;
            will-change: transform;
        }

        .se-hero__slide {
            position: relative;
            flex: 0 0 100%;
            width: 100%;
            min-height: 22rem;
            background-position: center;
            background-size: cover;
            background-repeat: no-repeat;
        }

        .se-hero__inner {
            position: relative;
            min-height: 22rem;
            margin: 0 auto;
            z-index: 1;
        }

        .se-hero__content {
            position: relative;
            z-index: 2;
            display: flex;
            flex-direction: column;
            justify-content: center;
            min-height: 22rem;
            padding: 3rem 1.25rem;
            max-width: 80rem;
            margin: 0 auto;
            box-sizing: border-box;
        }

        .se-hero__eyebrow {
            text-transform: uppercase;
            letter-spacing: .05em;
            font-size: .8125rem;
            font-weight: 600;
            color: #195c38;
            margin-bottom: .75rem;
        }

        .se-hero__title {
            font-size: 2.25rem;
            line-height: 1.1;
            font-weight: 700;
            color: #111827;
            margin-bottom: 1rem;
        }

        .se-hero__subtitle {
            color: #4b5563;
            margin-bottom: 1.5rem;
            max-width: 28rem;
        }

        .se-hero__cta {
            display: inline-flex;
            align-items: center;
            gap: .5rem;
            width: fit-content;
            background: #195c38;
            color: #fff;
            padding: .75rem 1.5rem;
            border-radius: .375rem;
            font-weight: 500;
        }

        .se-hero__cta:hover {
            background: #14472c;
        }

        .se-hero__media {
            position: absolute;
            inset: 0;
        }

        .se-hero__media img {
            position: absolute;
            inset: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .se-hero__slide::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(90deg, rgba(255, 255, 255, .94) 0%, rgba(255, 255, 255, .76) 32%, rgba(255, 255, 255, 0) 68%);
            pointer-events: none;
        }

        .se-hero__arrow {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            width: 2.5rem;
            height: 2.5rem;
            border-radius: 9999px;
            background: rgba(255, 255, 255, .9);
            color: #374151;
            display: none;
            align-items: center;
            justify-content: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, .2);
            z-index: 10;
            cursor: pointer;
            opacity: 0;
            pointer-events: none;
            transition: opacity .2s ease;
        }

        .se-hero:hover .se-hero__arrow {
            opacity: 1;
            pointer-events: auto;
        }

        .se-hero__arrow:hover {
            background: #fff;
        }

        .se-hero__arrow--prev {
            left: 1rem;
        }

        .se-hero__arrow--next {
            right: 1rem;
        }

        .se-hero__dots {
            position: absolute;
            bottom: 1.5rem;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            align-items: center;
            gap: .5rem;
            z-index: 10;
        }

        @media (min-width: 768px) {
            .se-hero__inner {
                min-height: 25rem;
            }

            .se-hero__content {
                min-height: 25rem;
                padding: 0 max(2rem, calc((100% - 80rem) / 2 + 2rem));
            }

            .se-hero__title {
                font-size: 2.75rem;
            }

            .se-hero__arrow {
                display: flex;
            }

        }

        /* ---------- GENERIC SLIDER (testimonials) ---------- */
        .se-slider {
            position: relative;
        }

        .se-slider__viewport {
            overflow: hidden;
        }

        .se-slider__track {
            display: flex;
            transition: transform .5s ease;
            will-change: transform;
        }

        /* mobile: 1 card per view */
        .se-slider__slide {
            flex: 0 0 100%;
            max-width: 100%;
            padding: 0 .5rem;
            box-sizing: border-box;
            display: flex;
        }

        .se-slider__slide>* {
            width: 100%;
        }

        .se-slider__arrow {
            position: absolute;
            top: 45%;
            transform: translateY(-50%);
            width: 2.25rem;
            height: 2.25rem;
            border-radius: 9999px;
            background: #fff;
            color: #4b5563;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, .15);
            z-index: 10;
            cursor: pointer;
        }

        .se-slider__arrow--prev {
            left: -.25rem;
        }

        .se-slider__arrow--next {
            right: -.25rem;
        }

        .se-slider__dots {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: .5rem;
            margin-top: 1.5rem;
        }

        /* desktop: 3 cards per view */
        @media (min-width: 768px) {
            .se-slider__slide {
                flex: 0 0 33.3333%;
                max-width: 33.3333%;
                padding: 0 .75rem;
            }

            .se-slider__arrow--prev {
                left: -1.25rem;
            }

            .se-slider__arrow--next {
                right: -1.25rem;
            }
        }
    </style>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>

    
    
    <section class="se-hero" data-carousel data-autoplay="6000">
        <div class="se-hero__track" data-carousel-track>
            <?php $__currentLoopData = $heroSlides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="se-hero__slide" data-carousel-slide>
                    <div class="se-hero__inner">
                        <div class="se-hero__content">
                            <p class="se-hero__eyebrow"><?php echo e($slide['eyebrow']); ?></p>
                            <h1 class="se-hero__title"><?php echo nl2br(e($slide['title'])); ?></h1>
                            <p class="se-hero__subtitle"><?php echo e($slide['subtitle']); ?></p>
                            <a href="<?php echo e($slide['cta_url']); ?>" class="se-hero__cta">
                                <?php echo e($slide['cta']); ?> <i class="fa-solid fa-arrow-right text-sm"></i>
                            </a>
                        </div>
                        <div class="se-hero__media">
                            <img src="<?php echo e($slide['image']); ?>" alt="<?php echo e($slide['title']); ?>">
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php if(count($heroSlides) > 1): ?>
            <button type="button" class="se-hero__arrow se-hero__arrow--prev" data-carousel-prev aria-label="Previous slide">
                <i class="fa-solid fa-chevron-left"></i>
            </button>
            <button type="button" class="se-hero__arrow se-hero__arrow--next" data-carousel-next aria-label="Next slide">
                <i class="fa-solid fa-chevron-right"></i>
            </button>
        <?php endif; ?>

        <div class="se-hero__dots" data-carousel-dots></div>
    </section>

    
    <section class="max-w-7xl mx-auto px-4 py-12">
        <div class="grid grid-cols-4 sm:grid-cols-8 gap-6 text-center">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('shop')); ?>?category=<?php echo e($cat['slug']); ?>" class="flex flex-col items-center gap-2 group">
                    <span
                        class="w-16 h-16 rounded-full <?php echo e($cat['bg']); ?> flex items-center justify-center <?php echo e($cat['color']); ?> text-xl group-hover:opacity-80">
                        <i class="<?php echo e($cat['icon']); ?>"></i>
                    </span>
                    <span class="text-xs font-medium text-gray-700"><?php echo e($cat['name']); ?></span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

    
    <section class="max-w-7xl mx-auto px-4 py-8">
        <div class="flex items-end justify-between mb-6">
            <div>
                <h2 class="text-2xl font-bold text-gray-900">New Arrivals</h2>
                <p class="text-gray-500 text-sm">Fresh styles. Latest trends. Just for you.</p>
            </div>
            <a href="<?php echo e(route('shop')); ?>" class="text-brand-700 text-sm font-medium hover:underline">View All <i
                    class="fa-solid fa-arrow-right text-xs"></i></a>
        </div>
        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-5">
            <?php $__currentLoopData = $newArrivals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'c44780d405f8ac2435a5fbd03229276a::product-card','data' => ['product' => $product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $attributes = $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $component = $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

    
    
    <section class="max-w-7xl mx-auto px-4 py-8 grid md:grid-cols-2 gap-6">
        <?php $__currentLoopData = $promoBanners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="relative rounded-xl overflow-hidden min-h-60 flex items-center">
                <img src="<?php echo e($banner['image']); ?>" alt="<?php echo e($banner['title']); ?>"
                    class="absolute inset-0 w-full h-full object-cover">
                <div class="absolute inset-0 bg-linear-to-t from-black/70 via-black/20 to-transparent"></div>

                <div class="relative z-10 px-6 sm:px-8 py-8">
                    <p class="text-white/80 text-sm mb-1"><?php echo e($banner['eyebrow']); ?></p>
                    <h3 class="text-2xl font-bold text-white mb-1"><?php echo e($banner['title']); ?></h3>
                    <p class="text-white/80 text-sm mb-5"><?php echo e($banner['subtitle']); ?></p>
                    <a href="<?php echo e(route('shop')); ?>?category=<?php echo e($banner['slug']); ?>"
                        class="inline-flex items-center gap-2 bg-white hover:bg-gray-100 text-gray-900 px-5 py-2.5 rounded-md text-sm font-medium">
                        <?php echo e($banner['cta']); ?> <i class="fa-solid fa-arrow-right text-xs"></i>
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>

    
    <section class="max-w-7xl mx-auto px-4 py-8">
        <div class="flex items-end justify-between mb-6">
            <div>
                <h2 class="text-2xl font-bold text-gray-900">Best Sellers</h2>
                <p class="text-gray-500 text-sm">Loved by customers. Always in demand.</p>
            </div>
            <a href="<?php echo e(route('shop')); ?>" class="text-brand-700 text-sm font-medium hover:underline">View All <i
                    class="fa-solid fa-arrow-right text-xs"></i></a>
        </div>
        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-5">
            <?php $__currentLoopData = $bestSellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'c44780d405f8ac2435a5fbd03229276a::product-card','data' => ['product' => $product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $attributes = $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $component = $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\user\index.blade.php ENDPATH**/ ?>