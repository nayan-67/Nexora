

<?php $__env->startSection('title', 'Create an Account — AgriExpress'); ?>

<?php
    $hideNewsletter = true;
    $hideFullFooter = true;
?>

<?php $__env->startSection('content'); ?>
    <div class="bg-brand-50 min-h-[calc(100vh-8rem)] flex items-center justify-center px-4 py-12">
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 w-full max-w-md p-8">
            <h1 class="text-2xl font-bold text-gray-900 text-center mb-1">Create an Account</h1>
            <p class="text-gray-500 text-sm text-center mb-6">Join AgriExpress and start shopping today</p>

            <?php if($errors->any()): ?>
                <div class="mb-5 rounded-md bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700" role="alert">
                    
                    <ul class="list-disc list-inside space-y-1">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('store')); ?>" method="POST" class="space-y-4">
                <?php echo csrf_field(); ?>
                <div>
                    <label for="register-name" class="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                    <input id="register-name" type="text" name="name" value="<?php echo e(old('name')); ?>"
                        placeholder="Your full name" required autofocus
                        class="w-full border <?php echo e($errors->has('name') ? 'border-red-400' : 'border-gray-200'); ?> rounded-md px-4 py-2.5 text-sm outline-none focus:border-brand-700">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-xs text-red-500 mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label for="register-phone" class="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                    <input id="register-phone" type="tel" name="phone" value="<?php echo e(old('phone')); ?>"
                        placeholder="Your phone number" required
                        class="w-full border <?php echo e($errors->has('phone') ? 'border-red-400' : 'border-gray-200'); ?> rounded-md px-4 py-2.5 text-sm outline-none focus:border-brand-700">
                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-xs text-red-500 mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label for="register-email" class="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                    <input id="register-email" type="email" name="email" value="<?php echo e(old('email')); ?>"
                        placeholder="you@example.com" required
                        class="w-full border <?php echo e($errors->has('email') ? 'border-red-400' : 'border-gray-200'); ?> rounded-md px-4 py-2.5 text-sm outline-none focus:border-brand-700">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-xs text-red-500 mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label for="register-password" class="block text-sm font-medium text-gray-700 mb-1">Password</label>
                    <div class="relative">
                        <input id="register-password" type="password" name="password" placeholder="Create a password"
                            required
                            class="w-full border <?php echo e($errors->has('password') ? 'border-red-400' : 'border-gray-200'); ?> rounded-md px-4 py-2.5 text-sm outline-none focus:border-brand-700">
                        <button type="button" data-toggle-password="#register-password" aria-label="Show password"
                            aria-pressed="false" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
                            <i class="fa-regular fa-eye icon-eye"></i>
                            <i class="fa-regular fa-eye-slash icon-eye-slash" style="display: none"></i>
                        </button>
                    </div>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-xs text-red-500 mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label for="register-password-confirmation" class="block text-sm font-medium text-gray-700 mb-1">Confirm
                        Password</label>
                    <input id="register-password-confirmation" type="password" name="password_confirmation"
                        placeholder="Repeat your password" required
                        class="w-full border border-gray-200 rounded-md px-4 py-2.5 text-sm outline-none focus:border-brand-700">
                </div>
                <button type="submit"
                    class="block w-full text-center bg-brand-700 hover:bg-brand-800 text-white py-3 rounded-md font-medium">Create
                    Account</button>
            </form>

            <p class="text-center text-sm text-gray-500 mt-6">Already have an account?
                <a href="<?php echo e(route('login')); ?>" class="text-brand-700 font-medium hover:underline">Sign in</a>
            </p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\user\auth\register.blade.php ENDPATH**/ ?>