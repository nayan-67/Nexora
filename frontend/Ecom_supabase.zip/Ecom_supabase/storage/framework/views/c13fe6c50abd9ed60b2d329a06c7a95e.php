<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> | AgriExpress</title>
    <link href="<?php echo e(asset('assets/images/favicon.png')); ?>" rel="icon" />

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/js/all.min.js" crossorigin="anonymous"></script>
    <?php echo $__env->yieldPushContent('head'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/admin.css')); ?>">
    <?php echo $__env->yieldContent('style'); ?>
</head>

<body class="min-h-screen">

    <?php ($activeNav = $__env->yieldContent('active')); ?>

    <div class="flex min-h-screen">
        <?php echo $__env->make('admin.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="flex-1 min-w-0 flex flex-col lg:ml-63">
            <?php echo $__env->make('admin.partials.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <main class="p-4 sm:p-6 flex-1">
                <?php if(session('status')): ?>
                    <div
                        class="mb-4 rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-700 text-sm px-4 py-3">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>

                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>

    <div id="toast"
        class="fixed bottom-6 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-sm px-5 py-2.5 rounded-lg opacity-0 pointer-events-none transition-opacity z-50">
    </div>

    <div id="confirm-modal" class="confirm-modal-overlay fixed inset-0 z-100 hidden items-center justify-center px-4" role="dialog"
        aria-modal="true" aria-labelledby="confirm-modal-title">
        <div class="confirm-modal-dialog w-full max-w-sm rounded-2xl p-6 shadow-2xl">
            <div class="flex items-center gap-4 ">
                <div class="confirm-modal-icon">
                    <i class="fa-solid fa-triangle-exclamation text-red-500" style="font-size: 40px;"></i>
                </div>
                <div>
                    <h2 id="confirm-modal-title" class="text-lg font-semibold">Confirm action</h2>
                    <p id="confirm-modal-message" class="mt-1 text-sm muted">Are you sure you want to continue?</p>
                </div>
            </div>
            <div class="mt-6 flex justify-end gap-3">
                <button type="button" data-confirm-cancel class="confirm-modal-cancel rounded-lg px-4 py-2 text-sm font-medium cursor-pointer">Cancel</button>
                <button type="button" data-confirm-submit class="confirm-modal-submit rounded-lg px-4 py-2 text-sm font-medium cursor-pointer">Continue</button>
            </div>
        </div>
    </div>

    <script src="<?php echo e(asset('assets/js/admin/admin.js')); ?>?v=<?php echo e(filemtime(public_path('assets/js/admin/admin.js'))); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\admin\layouts\admin.blade.php ENDPATH**/ ?>