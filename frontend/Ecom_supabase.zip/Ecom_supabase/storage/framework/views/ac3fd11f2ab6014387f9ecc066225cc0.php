<?php $__env->startSection('title', 'Blog — AgriExpress'); ?>

<?php $__env->startSection('content'); ?>

    <?php if (isset($component)) { $__componentOriginalb00c7f6baf7ea834a0251f4153d10b8b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb00c7f6baf7ea834a0251f4153d10b8b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'c44780d405f8ac2435a5fbd03229276a::page-banner','data' => ['eyebrow' => 'Our Blog','heading' => 'Tips, Trends &amp; Stories','subtitle' => 'Discover the latest trends, shopping tips, and inspiring stories from the AgriExpress community.','image' => 'https://images.unsplash.com/photo-1524758631624-e2822e304c36?w=1000&q=80','crumbs' => ['Home' => route('index'), 'Blog' => null]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['eyebrow' => 'Our Blog','heading' => 'Tips, Trends &amp; Stories','subtitle' => 'Discover the latest trends, shopping tips, and inspiring stories from the AgriExpress community.','image' => 'https://images.unsplash.com/photo-1524758631624-e2822e304c36?w=1000&q=80','crumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['Home' => route('index'), 'Blog' => null])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb00c7f6baf7ea834a0251f4153d10b8b)): ?>
<?php $attributes = $__attributesOriginalb00c7f6baf7ea834a0251f4153d10b8b; ?>
<?php unset($__attributesOriginalb00c7f6baf7ea834a0251f4153d10b8b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb00c7f6baf7ea834a0251f4153d10b8b)): ?>
<?php $component = $__componentOriginalb00c7f6baf7ea834a0251f4153d10b8b; ?>
<?php unset($__componentOriginalb00c7f6baf7ea834a0251f4153d10b8b); ?>
<?php endif; ?>

    <div class="max-w-7xl mx-auto px-4 py-10">

        
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <div class="flex flex-wrap items-center gap-2">
                <?php $__currentLoopData = $blogCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('blog')); ?><?php echo e($cat['slug'] ? '?category=' . $cat['slug'] : ''); ?>"
                        class="px-4 py-2 rounded-full text-sm font-medium transition
                  <?php echo e($activeCategory === $cat['slug']
                      ? 'bg-brand-700 text-white'
                      : 'border border-gray-200 text-gray-600 hover:border-brand-700 hover:text-brand-700'); ?>">
                        <?php echo e($cat['name']); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <form action="<?php echo e(route('blog')); ?>" method="GET"
                class="flex items-center bg-gray-100 rounded-full px-4 py-2 w-full md:w-64">
                <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Search blog posts..."
                    class="bg-transparent outline-none text-sm w-full">
                <button type="submit"><i class="fa-solid fa-magnifying-glass text-gray-500"></i></button>
            </form>
        </div>

        
        <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="border border-gray-100 rounded-lg overflow-hidden flex flex-col hover:shadow-md transition">
                    <div class="relative">
                        <span
                            class="absolute top-3 left-3 <?php echo e($post['tag_color']); ?> text-white text-[10px] font-semibold px-2.5 py-1 rounded"><?php echo e($post['tag']); ?></span>
                        <button data-wishlist-btn
                            class="absolute top-3 right-3 w-7 h-7 rounded-full bg-white/90 flex items-center justify-center text-gray-500 hover:text-rose-500">
                            <i class="fa-regular fa-bookmark text-xs"></i>
                        </button>
                        <img src="<?php echo e($post['image']); ?>" alt="<?php echo e($post['title']); ?>" class="w-full h-44 object-cover">
                    </div>

                    <div class="p-4 flex flex-col flex-1">
                        <h2 class="font-semibold text-gray-900 leading-snug mb-2">
                            <a href="<?php echo e(route('blog.show', $post['slug'])); ?>"
                                class="hover:text-brand-700"><?php echo e($post['title']); ?></a>
                        </h2>
                        <p class="text-sm text-gray-500 leading-relaxed mb-4 flex-1"><?php echo e($post['excerpt']); ?></p>

                        <div class="flex items-center justify-between mb-3">
                            <div class="flex items-center gap-2">
                                <img src="<?php echo e($post['author_avatar']); ?>" class="w-7 h-7 rounded-full object-cover">
                                <div class="leading-tight">
                                    <p class="text-xs font-medium text-gray-800"><?php echo e($post['author']); ?></p>
                                    <p class="text-[10px] text-gray-400"><?php echo e($post['date']); ?></p>
                                </div>
                            </div>
                            <span class="text-[10px] text-gray-400"><?php echo e($post['read_time']); ?></span>
                        </div>

                        <a href="<?php echo e(route('blog.show', $post['slug'])); ?>"
                            class="text-brand-700 text-sm font-medium hover:underline">
                            Read More <i class="fa-solid fa-arrow-right text-xs"></i>
                        </a>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <div class="flex items-center justify-center gap-2 mt-10">
            <button class="w-9 h-9 rounded-md border border-gray-200 text-gray-500 hover:bg-gray-50"><i
                    class="fa-solid fa-chevron-left text-xs"></i></button>
            <?php for($i = 1; $i <= 5; $i++): ?>
                <button
                    class="w-9 h-9 rounded-md text-sm font-medium <?php echo e($i === $currentPage ? 'bg-brand-700 text-white' : 'border border-gray-200 hover:bg-gray-50'); ?>"><?php echo e($i); ?></button>
            <?php endfor; ?>
            <button class="w-9 h-9 rounded-md border border-gray-200 text-gray-500 hover:bg-gray-50"><i
                    class="fa-solid fa-chevron-right text-xs"></i></button>
        </div>

        
        <div
            class="bg-brand-50 rounded-xl px-8 py-8 mt-12 flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden">
            <div class="relative z-10">
                <p class="uppercase tracking-wide text-xs font-semibold text-brand-700 mb-1">Stay Updated</p>
                <h3 class="text-xl font-bold text-gray-900 mb-1">Get the Latest News &amp; Offers</h3>
                <p class="text-gray-500 text-sm max-w-sm">Subscribe to our newsletter and be the first to know about new
                    products, discounts and stories.</p>
            </div>
            <form action="<?php echo e(route('newsletter.subscribe')); ?>" method="POST"
                class="flex gap-2 w-full md:w-auto relative z-10">
                <?php echo csrf_field(); ?>
                <input type="email" name="email" required placeholder="Enter your email address"
                    class="rounded-md px-4 py-2.5 text-sm border border-gray-200 outline-none focus:border-brand-700 w-full md:w-64">
                <button
                    class="bg-brand-700 hover:bg-brand-800 text-white px-5 py-2.5 rounded-md text-sm font-medium whitespace-nowrap">Subscribe</button>
            </form>
            <i class="fa-solid fa-paper-plane absolute right-6 bottom-4 text-brand-700/10 text-7xl pointer-events-none"></i>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\user\blog.blade.php ENDPATH**/ ?>