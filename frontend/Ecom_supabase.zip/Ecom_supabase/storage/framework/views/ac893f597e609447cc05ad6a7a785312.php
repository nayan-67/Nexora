
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['href' => '#', 'icon', 'active' => null, 'badge' => null, 'chevron' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['href' => '#', 'icon', 'active' => null, 'badge' => null, 'chevron' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $isActive =
        $active !== null &&
        (($active === 'dashboard' && request()->routeIs('admin.dashboard')) ||
            ($active !== 'dashboard' && request()->routeIs('admin.' . $active . '*')));
?>
<a href="<?php echo e($href); ?>"
    class="side-link flex items-center gap-3 px-3.5 py-2.5 rounded-lg <?php echo e($isActive ? 'active' : ''); ?>">
    <i class="<?php echo e($icon); ?> w-4"></i>
    <?php echo e($slot); ?>

    <?php if($badge): ?>
        <span class="ml-auto text-[11px] bg-red-500 text-white rounded-full px-2 py-0.5"><?php echo e($badge); ?></span>
    <?php elseif($chevron === 'down'): ?>
        <i class="fa-solid fa-chevron-down ml-auto text-[10px] opacity-60"></i>
    <?php elseif($chevron === 'right'): ?>
        <i class="fa-solid fa-chevron-right ml-auto text-[10px] opacity-60"></i>
    <?php endif; ?>
</a>
<?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\admin\components\nav-link.blade.php ENDPATH**/ ?>