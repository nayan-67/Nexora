<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['editRoute' => '#', 'deleteRoute' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['editRoute' => '#', 'deleteRoute' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<div class="flex items-center gap-2 text-[13px]">
    <a href="<?php echo e($editRoute); ?>" class="w-8 h-8 rounded-lg border bd grid place-items-center text-blue-600" aria-label="Edit">
        <i class="fa-regular fa-pen-to-square"></i>
    </a>
    <?php if($deleteRoute): ?>
        <form action="<?php echo e($deleteRoute); ?>" method="POST" data-confirm-message="Delete this item? This cannot be undone.">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="w-8 h-8 rounded-lg border bd grid place-items-center text-red-500" aria-label="Delete">
                <i class="fa-regular fa-trash-can"></i>
            </button>
        </form>
    <?php endif; ?>
    <button type="button" class="w-8 h-8 rounded-lg grid place-items-center muted" aria-label="More">
        <i class="fa-solid fa-ellipsis-vertical"></i>
    </button>
</div>
<?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\admin\components\action-buttons.blade.php ENDPATH**/ ?>