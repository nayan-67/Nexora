<?php $__env->startSection('title', 'Order '.$order->order_number); ?>
<?php $__env->startSection('active', 'orders'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex flex-wrap gap-3 items-center justify-between mb-5">
    <div>
        <h1 class="text-2xl font-bold">Order details</h1>
        <p class="text-sm mt-1">
            <a href="<?php echo e(route('admin.orders.index')); ?>" class="text-blue-600">Orders</a>
            <i class="fa-solid fa-chevron-right text-[9px] muted mx-1"></i>
            <span class="muted"><?php echo e($order->order_number); ?></span>
        </p>
    </div>
    <div class="flex gap-2 items-center">
        <?php if (isset($component)) { $__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::pill','data' => ['status' => $order->order_status_label]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->order_status_label)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67)): ?>
<?php $attributes = $__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67; ?>
<?php unset($__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67)): ?>
<?php $component = $__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67; ?>
<?php unset($__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67); ?>
<?php endif; ?>
        <button class="surface border rounded-lg px-4 h-10 text-sm" onclick="window.print()"><i class="fa-solid fa-print mr-2 muted"></i>Print</button>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-5">
    <div class="surface border rounded-2xl p-5 space-y-5 h-fit">
        <div>
            <h2 class="font-semibold"><?php echo e($order->order_number); ?></h2>
            <p class="text-[12.5px] muted mt-0.5">Placed on <?php echo e(($order->placed_at ?? $order->created_at)->format('M j, Y, g:i A')); ?></p>
        </div>

        <div class="flex items-center gap-3 pt-4 border-t bd">
            <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::avatar','data' => ['name' => $order->user->name ?? 'Guest']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->user->name ?? 'Guest')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
            <div class="text-sm">
                <p class="font-medium"><?php echo e($order->user->name ?? 'Guest checkout'); ?></p>
                <?php if($order->user): ?>
                    <p class="muted text-[12.5px]"><?php echo e($order->user->email); ?></p>
                    <p class="muted text-[12.5px]"><?php echo e($order->user->phone); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <?php if($order->shippingAddress): ?>
            <div class="pt-4 border-t bd text-sm">
                <p class="font-medium mb-1.5">Shipping address</p>
                <p class="muted leading-relaxed text-[13px]">
                    <?php echo e($order->shippingAddress->full_name); ?><br>
                    <?php echo e($order->shippingAddress->address_line_1); ?><?php if($order->shippingAddress->address_line_2): ?>, <?php echo e($order->shippingAddress->address_line_2); ?><?php endif; ?><br>
                    <?php echo e($order->shippingAddress->city); ?>, <?php echo e($order->shippingAddress->state); ?> <?php echo e($order->shippingAddress->postal_code); ?><br>
                    <?php echo e($order->shippingAddress->phone); ?>

                </p>
            </div>
        <?php endif; ?>

        <div class="pt-4 border-t bd text-sm">
            <p class="font-medium mb-1.5">Payment</p>
            <p class="muted text-[13px]"><?php echo e($order->payment_mode ?? 'Not specified'); ?> &middot; <?php if (isset($component)) { $__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::pill','data' => ['status' => $order->payment_status_label]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->payment_status_label)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67)): ?>
<?php $attributes = $__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67; ?>
<?php unset($__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67)): ?>
<?php $component = $__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67; ?>
<?php unset($__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67); ?>
<?php endif; ?></p>
        </div>

        <form action="<?php echo e(route('admin.orders.updateStatus', $order)); ?>" method="POST" class="pt-4 border-t bd">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <label for="order_status" class="block mb-1.5 font-medium text-sm">Update status</label>
            <div class="flex gap-2">
                <select id="order_status" name="order_status" class="flex-1 border bd rounded-lg px-3 h-10 text-sm">
                    <?php $__currentLoopData = \App\Models\Order::STATUS_LABELS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>" <?php if($order->order_status === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="submit" class="bg-blue-600 hover:bg-blue-500 text-white rounded-lg px-4 text-sm font-medium">Save</button>
            </div>
        </form>

        <form action="<?php echo e(route('admin.orders.updatePaymentStatus', $order)); ?>" method="POST" class="pt-4 border-t bd">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <label for="payment_status" class="block mb-1.5 font-medium text-sm">Update payment status</label>
            <div class="flex gap-2">
                <select id="payment_status" name="payment_status" class="flex-1 border bd rounded-lg px-3 h-10 text-sm">
                    <?php $__currentLoopData = \App\Models\Order::PAYMENT_STATUS_LABELS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>" <?php if($order->payment_status === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="submit" class="bg-blue-600 hover:bg-blue-500 text-white rounded-lg px-4 text-sm font-medium">Save</button>
            </div>
            <p class="text-[11.5px] muted mt-1.5">
                Manual override — Stripe orders update this automatically once the webhook confirms payment.
                Use this for COD orders, refunds, or fixing a payment that didn't sync.
            </p>
        </form>
    </div>

    <div class="space-y-5">
        <div class="surface border rounded-2xl p-5">
            <h2 class="font-semibold mb-4">Order items</h2>
            <div class="scroll-x">
                <table class="w-full text-sm min-w-130">
                    <thead><tr class="text-left muted text-[12.5px] border-b bd">
                        <th class="pb-3 font-medium">Product</th><th class="pb-3 font-medium">Qty</th>
                        <th class="pb-3 font-medium">Price</th><th class="pb-3 font-medium text-right">Subtotal</th>
                    </tr></thead>
                    <tbody class="divide-b">
                        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="py-3.5">
                                    <span class="flex items-center gap-3">
                                        <?php if (isset($component)) { $__componentOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::thumb','data' => ['src' => $item->image_url,'icon' => 'fa-box','size' => 'w-10 h-10']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('thumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->image_url),'icon' => 'fa-box','size' => 'w-10 h-10']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8)): ?>
<?php $attributes = $__attributesOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8; ?>
<?php unset($__attributesOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8)): ?>
<?php $component = $__componentOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8; ?>
<?php unset($__componentOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8); ?>
<?php endif; ?>
                                        <span><span class="block font-medium"><?php echo e($item->product_name); ?></span><span class="block muted text-[12px]"><?php echo e($item->variant_name ?? $item->sku); ?></span></span>
                                    </span>
                                </td>
                                <td class="py-3.5"><?php echo e($item->quantity); ?></td>
                                <td class="py-3.5">$<?php echo e(number_format($item->unit_price, 2)); ?></td>
                                <td class="py-3.5 text-right font-medium">$<?php echo e(number_format($item->total_price, 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-5 ml-auto w-full sm:w-75 text-sm space-y-2.5">
                <div class="flex justify-between"><span class="muted">Subtotal</span><span>$<?php echo e(number_format($order->subtotal, 2)); ?></span></div>
                <div class="flex justify-between"><span class="muted">Discount</span><span class="text-red-500">-$<?php echo e(number_format($order->discount, 2)); ?></span></div>
                <?php if($order->eco_tax > 0): ?>
                    <div class="flex justify-between"><span class="muted">Eco tax</span><span>$<?php echo e(number_format($order->eco_tax, 2)); ?></span></div>
                <?php endif; ?>
                <div class="flex justify-between"><span class="muted">Shipping</span><span>$<?php echo e(number_format($order->shipping, 2)); ?></span></div>
                <div class="flex justify-between font-semibold text-base pt-3 border-t bd"><span>Total</span><span>$<?php echo e(number_format($order->total_price, 2)); ?></span></div>
                <?php if($order->coupon_code): ?>
                    <p class="text-[11.5px] muted">Coupon applied: <span class="font-medium"><?php echo e($order->coupon_code); ?></span></p>
                <?php endif; ?>
            </div>
        </div>

        <?php if($order->customer_note): ?>
            <div class="surface border rounded-2xl p-5">
                <h2 class="font-semibold mb-2">Customer note</h2>
                <p class="text-sm muted"><?php echo e($order->customer_note); ?></p>
            </div>
        <?php endif; ?>

        <?php if($order->payments->isNotEmpty()): ?>
            <div class="surface border rounded-2xl p-5">
                <h2 class="font-semibold mb-3">Payment history</h2>
                <ul class="divide-b text-sm">
                    <?php $__currentLoopData = $order->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="py-2.5 flex items-center justify-between">
                            <span><?php echo e($payment->payment_method); ?> &middot; <span class="muted"><?php echo e($payment->transaction_id ?? '—'); ?></span></span>
                            <span class="font-medium">$<?php echo e(number_format($payment->amount, 2)); ?></span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\admin\pages\orders\show.blade.php ENDPATH**/ ?>