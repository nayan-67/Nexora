<?php $__env->startSection('title', $category->exists ? 'Edit category' : 'Add category'); ?>
<?php $__env->startSection('active', 'categories'); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e($category->exists ? route('admin.categories.update', $category) : route('admin.categories.store')); ?>"
      method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php if($category->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

    <div class="flex flex-wrap gap-3 items-center justify-between mb-5">
        <div>
            <h1 class="text-2xl font-bold"><?php echo e($category->exists ? 'Edit category' : 'Add category'); ?></h1>
            <p class="muted text-sm mt-1">Organize your products into browsable categories</p>
        </div>
        <div class="flex gap-2">
            <a href="<?php echo e(route('admin.categories.index')); ?>" class="surface border rounded-lg px-4 h-10 text-sm flex items-center">Cancel</a>
            <button type="submit" class="bg-blue-600 hover:bg-blue-500 text-white rounded-lg px-4 h-10 text-sm font-medium">Save category</button>
        </div>
    </div>

    <?php if($errors->any()): ?>
        <div class="mb-5 rounded-xl border border-red-200 bg-red-50 text-red-700 text-[13px] px-4 py-3"><?php echo e($errors->first()); ?></div>
    <?php endif; ?>

    <div class="grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-5">
        <div class="surface border rounded-2xl p-5 space-y-4 text-sm h-fit">
            <div>
                <label for="name" class="block mb-1.5 font-medium">Name <span class="text-red-500">*</span></label>
                <input id="name" name="name" required value="<?php echo e(old('name', $category->name)); ?>" class="w-full border bd rounded-lg px-3 h-10">
            </div>
            <div class="grid sm:grid-cols-2 gap-4">
                <div>
                    <label for="slug" class="block mb-1.5 font-medium">Slug</label>
                    <input id="slug" name="slug" value="<?php echo e(old('slug', $category->slug)); ?>" class="w-full border bd rounded-lg px-3 h-10" placeholder="auto-generate-from-name">
                </div>
                <div>
                    <label for="parent_id" class="block mb-1.5 font-medium">Parent category</label>
                    <select id="parent_id" name="parent_id" class="w-full border bd rounded-lg px-3 h-10">
                        <option value="">None (top-level)</option>
                        <?php $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id); ?>" <?php if(old('parent_id', $category->parent_id) == $p->id): echo 'selected'; endif; ?>><?php echo e($p->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div>
                <label for="menu_name" class="block mb-1.5 font-medium">Menu display name</label>
                <input id="menu_name" name="menu_name" value="<?php echo e(old('menu_name', $category->menu_name)); ?>" class="w-full border bd rounded-lg px-3 h-10" placeholder="Shown in the storefront nav, if different from Name">
            </div>
            <div>
                <label for="description" class="block mb-1.5 font-medium">Description</label>
                <textarea id="description" name="description" rows="4" class="w-full border bd rounded-lg px-3 py-2"><?php echo e(old('description', $category->description)); ?></textarea>
            </div>
            <div class="grid sm:grid-cols-2 gap-4">
                <div>
                    <label for="sort_order" class="block mb-1.5 font-medium">Sort order</label>
                    <input id="sort_order" name="sort_order" type="number" value="<?php echo e(old('sort_order', $category->sort_order ?? 0)); ?>" class="w-full border bd rounded-lg px-3 h-10">
                </div>
                <label class="flex items-center gap-2 self-end pb-2 cursor-pointer">
                    <input type="checkbox" name="status" value="1" class="w-4 h-4 rounded accent-blue-600" <?php if(old('status', $category->status ?? true)): echo 'checked'; endif; ?>>
                    Active
                </label>
            </div>

            <div class="pt-4 border-t bd">
                <p class="font-medium mb-3">SEO</p>
                <div class="space-y-3">
                    <div>
                        <label for="meta_title" class="block mb-1.5 font-medium">Meta title</label>
                        <input id="meta_title" name="meta_title" value="<?php echo e(old('meta_title', $category->meta_title)); ?>" class="w-full border bd rounded-lg px-3 h-10">
                    </div>
                    <div>
                        <label for="meta_description" class="block mb-1.5 font-medium">Meta description</label>
                        <textarea id="meta_description" name="meta_description" rows="2" class="w-full border bd rounded-lg px-3 py-2"><?php echo e(old('meta_description', $category->meta_description)); ?></textarea>
                    </div>
                </div>
            </div>
        </div>

        <div class="space-y-5">
            <div class="surface border rounded-2xl p-5">
                <h2 class="font-semibold mb-3">Category image</h2>
                <label for="image" class="block relative border-2 border-dashed rounded-xl text-center cursor-pointer overflow-hidden" style="border-color:#c7d6f5;background:var(--bg)">
                    <div id="imagePreviewWrap" class="<?php echo e($category->image_url ? '' : 'hidden'); ?>">
                        <img id="imagePreview" src="<?php echo e($category->image_url); ?>" class="w-full h-32 object-cover">
                    </div>
                    <div id="imagePlaceholder" class="py-7 <?php echo e($category->image_url ? 'hidden' : ''); ?>">
                        <i class="fa-solid fa-image text-xl text-blue-500"></i>
                        <p class="text-[13px] mt-2 font-medium">Click to upload</p>
                        <p class="text-[11px] muted mt-0.5">Square image works best</p>
                    </div>
                    <input type="file" id="image" name="image" accept="image/*" class="hidden">
                </label>
            </div>

            <div class="surface border rounded-2xl p-5">
                <h2 class="font-semibold mb-3">Banner image</h2>
                <label for="banner" class="block relative border-2 border-dashed rounded-xl text-center cursor-pointer overflow-hidden" style="border-color:#c7d6f5;background:var(--bg)">
                    <div id="bannerPreviewWrap" class="<?php echo e($category->banner_url ? '' : 'hidden'); ?>">
                        <img id="bannerPreview" src="<?php echo e($category->banner_url); ?>" class="w-full h-24 object-cover">
                    </div>
                    <div id="bannerPlaceholder" class="py-7 <?php echo e($category->banner_url ? 'hidden' : ''); ?>">
                        <i class="fa-solid fa-panorama text-xl text-blue-500"></i>
                        <p class="text-[13px] mt-2 font-medium">Click to upload</p>
                        <p class="text-[11px] muted mt-0.5">Wide image for the category page header</p>
                    </div>
                    <input type="file" id="banner" name="banner" accept="image/*" class="hidden">
                </label>
            </div>

            <div class="surface border rounded-2xl p-5">
                <h2 class="font-semibold mb-3">SVG Icon</h2>
                <textarea name="svg_icon" id="" cols="30" rows="6" class="block relative border border-[#c7d6f5] rounded-md outline-0 p-2 w-full text-sm" style="background:var(--bg);outline: none;"><?php echo e($category->svg_icon ?? ''); ?></textarea>
                <small class="text-muted text-xs mt-3 leading-0">Use the SVG height & width to <strong>16</strong> and stroke-width to <strong>1.75</strong>.</small>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function wireImagePreview(inputId, previewId, wrapId, placeholderId){
    const input = document.getElementById(inputId);
    const preview = document.getElementById(previewId);
    const wrap = document.getElementById(wrapId);
    const placeholder = document.getElementById(placeholderId);

    input.addEventListener('change', () => {
        const file = input.files[0];
        if (!file) return;
        preview.src = URL.createObjectURL(file);
        wrap.classList.remove('hidden');
        placeholder.classList.add('hidden');
    });
}

wireImagePreview('image', 'imagePreview', 'imagePreviewWrap', 'imagePlaceholder');
wireImagePreview('banner', 'bannerPreview', 'bannerPreviewWrap', 'bannerPlaceholder');
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\admin\pages\categories\create.blade.php ENDPATH**/ ?>