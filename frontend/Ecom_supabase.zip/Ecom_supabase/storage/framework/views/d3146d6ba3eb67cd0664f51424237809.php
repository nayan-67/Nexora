<?php $__env->startSection('title', 'Contact Us — AgriExpress'); ?>

<?php $__env->startSection('content'); ?>

    <?php if (isset($component)) { $__componentOriginalb00c7f6baf7ea834a0251f4153d10b8b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb00c7f6baf7ea834a0251f4153d10b8b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'c44780d405f8ac2435a5fbd03229276a::page-banner','data' => ['eyebrow' => 'Get In Touch','heading' => 'We\'d Love to Hear<br>from You','subtitle' => 'Have a question, feedback or need assistance? Our team is here to help. Reach out to us anytime.','image' => 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=1000&q=80','crumbs' => ['Home' => route('index'), 'Contact' => null]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['eyebrow' => 'Get In Touch','heading' => 'We\'d Love to Hear<br>from You','subtitle' => 'Have a question, feedback or need assistance? Our team is here to help. Reach out to us anytime.','image' => 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=1000&q=80','crumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['Home' => route('index'), 'Contact' => null])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb00c7f6baf7ea834a0251f4153d10b8b)): ?>
<?php $attributes = $__attributesOriginalb00c7f6baf7ea834a0251f4153d10b8b; ?>
<?php unset($__attributesOriginalb00c7f6baf7ea834a0251f4153d10b8b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb00c7f6baf7ea834a0251f4153d10b8b)): ?>
<?php $component = $__componentOriginalb00c7f6baf7ea834a0251f4153d10b8b; ?>
<?php unset($__componentOriginalb00c7f6baf7ea834a0251f4153d10b8b); ?>
<?php endif; ?>

    <div class="max-w-7xl mx-auto px-4 py-12 grid lg:grid-cols-[1fr_380px] gap-8">

        
        <div class="border border-gray-100 rounded-xl p-8">
            <h2 class="text-xl font-bold text-gray-900 mb-1">Send Us a Message</h2>
            <p class="text-gray-500 text-sm mb-6">Fill out the form below and we'll get back to you as soon as possible.</p>

            <?php if(session('status')): ?>
                <div class="bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm rounded-md px-4 py-3 mb-6">
                    <i class="fa-solid fa-circle-check mr-2"></i><?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('contact.send')); ?>" method="POST" class="space-y-5">
                <?php echo csrf_field(); ?>

                <div>
                    <label for="name" class="block text-sm font-medium text-gray-700 mb-1">Full Name <span
                            class="text-red-500">*</span></label>
                    <input id="name" type="text" name="name" value="<?php echo e(old('name')); ?>" required
                        placeholder="Your name"
                        class="w-full border border-gray-200 rounded-md px-4 py-2.5 text-sm outline-none focus:border-brand-700">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-xs text-red-500 mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email Address <span
                            class="text-red-500">*</span></label>
                    <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required
                        placeholder="you@example.com"
                        class="w-full border border-gray-200 rounded-md px-4 py-2.5 text-sm outline-none focus:border-brand-700">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-xs text-red-500 mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label for="phone" class="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                    <input id="phone" type="tel" name="phone" value="<?php echo e(old('phone')); ?>"
                        placeholder="+91 98765 43210"
                        class="w-full border border-gray-200 rounded-md px-4 py-2.5 text-sm outline-none focus:border-brand-700">
                </div>

                <div>
                    <label for="subject" class="block text-sm font-medium text-gray-700 mb-1">Subject <span
                            class="text-red-500">*</span></label>
                    <select id="subject" name="subject" required
                        class="w-full border border-gray-200 rounded-md px-4 py-2.5 text-sm outline-none focus:border-brand-700 bg-white text-gray-600">
                        <option value="">Select a subject</option>
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($subject); ?>" <?php if(old('subject') === $subject): echo 'selected'; endif; ?>><?php echo e($subject); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-xs text-red-500 mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label for="message" class="block text-sm font-medium text-gray-700 mb-1">Message <span
                            class="text-red-500">*</span></label>
                    <textarea id="message" name="message" rows="5" required placeholder="Type your message here..."
                        class="w-full border border-gray-200 rounded-md px-4 py-2.5 text-sm outline-none focus:border-brand-700 resize-y"><?php echo e(old('message')); ?></textarea>
                    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-xs text-red-500 mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button type="submit"
                    class="w-full bg-brand-700 hover:bg-brand-800 text-white py-3 rounded-md font-medium flex items-center justify-center gap-2">
                    Send Message <i class="fa-solid fa-arrow-right text-sm"></i>
                </button>
            </form>
        </div>

        
        <aside class="space-y-6">
            <div class="border border-gray-100 rounded-xl p-6">
                <h2 class="font-bold text-gray-900 mb-1">Contact Information</h2>
                <p class="text-gray-500 text-sm mb-6">You can also reach us through the following channels.</p>

                <ul class="space-y-5">
                    <?php $__currentLoopData = $contactChannels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="flex gap-3">
                            <span
                                class="w-9 h-9 shrink-0 rounded-full bg-brand-50 flex items-center justify-center text-brand-700">
                                <i class="<?php echo e($channel['icon']); ?>"></i>
                            </span>
                            <div class="text-sm">
                                <p class="font-medium text-gray-900"><?php echo e($channel['label']); ?></p>
                                <?php $__currentLoopData = $channel['lines']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!empty($channel['href']) && $loop->first): ?>
                                        <a href="<?php echo e($channel['href']); ?>"
                                            class="text-gray-500 hover:text-brand-700 block"><?php echo e($line); ?></a>
                                    <?php else: ?>
                                        <p class="text-gray-500"><?php echo e($line); ?></p>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <div class="border border-gray-100 rounded-xl p-6">
                <h2 class="font-bold text-gray-900 mb-1">Follow Us</h2>
                <p class="text-gray-500 text-sm mb-4">Stay connected for the latest updates, offers and more.</p>
                <div class="flex gap-3">
                    <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($social['url']); ?>" aria-label="<?php echo e($social['name']); ?>"
                            class="w-10 h-10 rounded-full bg-brand-50 flex items-center justify-center text-brand-700 hover:bg-brand-700 hover:text-white transition">
                            <i class="<?php echo e($social['icon']); ?>"></i>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </aside>
    </div>

    
    <div class="max-w-7xl mx-auto px-4 pb-6">
        <div class="relative rounded-xl overflow-hidden border border-gray-100 h-80">
            <iframe src="<?php echo e($mapEmbedUrl); ?>" class="w-full h-full border-0" allowfullscreen loading="lazy"
                referrerpolicy="no-referrer-when-downgrade" title="AgriExpress store location"></iframe>

            
            <div class="absolute top-6 left-6 bg-white rounded-lg shadow-lg px-5 py-4 max-w-xs">
                <p class="font-semibold text-gray-900 text-sm mb-1"><?php echo e($storeName); ?></p>
                <p class="text-xs text-gray-500 leading-relaxed">
                    <?php echo e($storeAddress['line1']); ?><br><?php echo e($storeAddress['city']); ?></p>
            </div>
        </div>
    </div>

    
    <div class="max-w-7xl mx-auto px-4 pb-12">
        <div class="bg-brand-50 rounded-xl px-8 py-6 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div class="flex items-center gap-4">
                <span
                    class="w-12 h-12 shrink-0 rounded-full bg-white flex items-center justify-center text-brand-700 text-xl shadow-sm">
                    <i class="fa-solid fa-headset"></i>
                </span>
                <div>
                    <p class="font-semibold text-gray-900">Need Help?</p>
                    <p class="text-gray-500 text-sm">Our support team is available 24/7 to assist you with any questions or
                        concerns.</p>
                </div>
            </div>
            <button
                class="bg-brand-700 hover:bg-brand-800 text-white px-6 py-3 rounded-md font-medium whitespace-nowrap flex items-center gap-2">
                Chat With Us <i class="fa-solid fa-arrow-right text-sm"></i>
            </button>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\user\contact.blade.php ENDPATH**/ ?>