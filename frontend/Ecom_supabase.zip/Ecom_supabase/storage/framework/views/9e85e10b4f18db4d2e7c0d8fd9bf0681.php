<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Sign in'); ?> | AgriExpress</title>
    <link href="<?php echo e(asset('assets/images/favicon.png')); ?>" rel="icon" />

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/js/all.min.js" crossorigin="anonymous"></script>
    <?php echo $__env->yieldPushContent('head'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/admin.css')); ?>">
    <style>
        body {
            background: radial-gradient(1200px 600px at 50% -10%, #eef2ff 0%, #eef1f8 55%);
        }
    </style>
</head>

<body class="min-h-screen">

    <?php echo $__env->yieldContent('content'); ?>

    <div id="toast"
        class="fixed bottom-6 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-sm px-5 py-2.5 rounded-lg opacity-0 pointer-events-none transition-opacity z-50">
    </div>

    <script src="<?php echo e(asset('assets/js/admin/admin.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\admin\layouts\guest.blade.php ENDPATH**/ ?>