<?php $__env->startSection('title', 'Reviews'); ?>
<?php $__env->startSection('active', 'reviews'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex flex-wrap gap-3 items-center justify-between mb-5">
    <div><h1 class="text-2xl font-bold">Reviews</h1><p class="muted text-sm mt-1">Moderate product reviews before they go live</p></div>
</div>

<div class="surface border rounded-2xl">
    <div class="flex gap-6 px-5 border-b bd overflow-x-auto text-sm">
        <?php $activeStatus = request('status', 'pending'); ?>
        <?php $__currentLoopData = ['pending' => 'Pending', 'approved' => 'Approved']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('admin.reviews.index', ['status' => $key])); ?>"
               class="py-3.5 font-medium border-b-2 whitespace-nowrap <?php echo e($activeStatus === $key ? 'border-blue-600 text-blue-600' : 'border-transparent muted'); ?>">
                <?php echo e($label); ?>

            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="divide-y" style="border-color:var(--border)">
        <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="p-5 flex flex-col sm:flex-row gap-4">
                <div class="flex items-center gap-3 sm:w-56 shrink-0">
                    <?php if (isset($component)) { $__componentOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::thumb','data' => ['icon' => 'fa-box','tone' => 'bg-slate-100 text-slate-600','size' => 'w-11 h-11']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('thumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('fa-box'),'tone' => 'bg-slate-100 text-slate-600','size' => 'w-11 h-11']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8)): ?>
<?php $attributes = $__attributesOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8; ?>
<?php unset($__attributesOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8)): ?>
<?php $component = $__componentOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8; ?>
<?php unset($__componentOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8); ?>
<?php endif; ?>
                    <div class="min-w-0">
                        <p class="font-medium text-sm truncate"><?php echo e($review->product->name ?? 'Deleted product'); ?></p>
                        <p class="muted text-[12px]"><?php echo e($review->created_at->format('M d, Y')); ?></p>
                    </div>
                </div>

                <div class="flex-1 min-w-0">
                    <div class="flex items-center gap-2 flex-wrap">
                        <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::avatar','data' => ['name' => $review->user->name ?? 'Guest']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($review->user->name ?? 'Guest')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                        <span class="font-medium text-sm"><?php echo e($review->user->name ?? 'Guest'); ?></span>
                        <?php if($review->is_verified_purchase): ?>
                            <span class="text-[11px] font-semibold text-emerald-700 bg-emerald-100 rounded-full px-2 py-0.5">Verified purchase</span>
                        <?php endif; ?>
                        <span class="ml-auto sm:ml-0 flex items-center gap-0.5 text-amber-400 text-[13px]">
                            <?php for($i = 1; $i <= 5; $i++): ?>
                                <i class="fa-<?php echo e($i <= $review->rating ? 'solid' : 'regular'); ?> fa-star"></i>
                            <?php endfor; ?>
                        </span>
                    </div>
                    <?php if($review->title): ?>
                        <p class="font-medium text-sm mt-2"><?php echo e($review->title); ?></p>
                    <?php endif; ?>
                    <?php if($review->comment): ?>
                        <p class="muted text-[13px] mt-1 leading-relaxed"><?php echo e($review->comment); ?></p>
                    <?php endif; ?>
                </div>

                <div class="flex sm:flex-col gap-2 sm:w-32 shrink-0">
                    <form action="<?php echo e(route('admin.reviews.updateStatus', $review)); ?>" method="POST" class="flex-1">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <input type="hidden" name="status" value="<?php echo e($review->status ? 0 : 1); ?>">
                        <button type="submit" class="w-full border bd rounded-lg h-9 text-[13px] font-medium <?php echo e($review->status ? 'text-amber-600' : 'text-emerald-600'); ?>">
                            <?php echo e($review->status ? 'Unpublish' : 'Approve'); ?>

                        </button>
                    </form>
                    <form action="<?php echo e(route('admin.reviews.destroy', $review)); ?>" method="POST" class="flex-1" data-confirm-message="Delete this review?">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="w-full border bd rounded-lg h-9 text-[13px] font-medium text-red-500">Delete</button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="p-10 text-center muted text-sm">Nothing to moderate here.</p>
        <?php endif; ?>
    </div>

    <?php if (isset($component)) { $__componentOriginala58819cbc116d88f8edc7af8663d5cf9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala58819cbc116d88f8edc7af8663d5cf9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::pagination-bar','data' => ['paginator' => $reviews]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($reviews)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala58819cbc116d88f8edc7af8663d5cf9)): ?>
<?php $attributes = $__attributesOriginala58819cbc116d88f8edc7af8663d5cf9; ?>
<?php unset($__attributesOriginala58819cbc116d88f8edc7af8663d5cf9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala58819cbc116d88f8edc7af8663d5cf9)): ?>
<?php $component = $__componentOriginala58819cbc116d88f8edc7af8663d5cf9; ?>
<?php unset($__componentOriginala58819cbc116d88f8edc7af8663d5cf9); ?>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\admin\pages\reviews\index.blade.php ENDPATH**/ ?>