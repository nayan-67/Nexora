<?php $__env->startSection('title', 'Your Cart — AgriExpress'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-7xl mx-auto px-4 py-8">
        <h1 class="text-2xl font-bold text-gray-900 mb-1">Your Cart</h1>
        <p class="text-gray-500 text-sm mb-6"><?php echo e(count($cartItems)); ?> items</p>

        <div class="grid lg:grid-cols-[1fr_360px] gap-8">
            <div>
                <?php if(session('status')): ?>
                    <div class="mb-5 rounded-md bg-emerald-50 border border-emerald-200 px-4 py-3 text-sm text-emerald-700">
                        <?php echo e(session('status')); ?></div>
                <?php endif; ?>

                <div class="divide-y divide-gray-100 border border-gray-100 rounded-lg" data-cart-totals
                    data-discount-pct="<?php echo e($discountPct); ?>" data-tax-pct="<?php echo e($taxPct); ?>">
                    <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center gap-4 p-4" data-cart-row data-price="<?php echo e($item['price']); ?>"
                            data-update-url="<?php echo e(route('cart.update', $item['id'])); ?>">
                            <img src="<?php echo e($item['image']); ?>" class="w-20 h-20 rounded-md object-cover shrink-0">

                            <div class="flex-1 min-w-0">
                                <div class="flex items-start justify-between gap-4">
                                    <div class="min-w-0">
                                        <p class="font-medium text-gray-900 truncate"><?php echo e($item['name']); ?></p>
                                        <p class="text-xs text-gray-500"><?php echo e($item['variant']); ?></p>
                                    </div>
                                    <div class="flex items-center gap-2 shrink-0">
                                        <span class="font-semibold text-gray-900"
                                            data-line-total>$<?php echo e(number_format($item['price'] * $item['qty'], 2)); ?></span>
                                        <?php if($item['old_price']): ?>
                                            <span
                                                class="text-gray-400 line-through text-xs">$<?php echo e(number_format($item['old_price'], 2)); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="flex items-center justify-between mt-3">
                                    <div class="flex items-center border border-gray-200 rounded-md" data-qty data-min="1"
                                        data-max="10">
                                        <button type="button" data-qty-decrease
                                            class="w-8 h-8 text-gray-600 hover:bg-gray-50">&minus;</button>
                                        <span data-qty-value class="w-8 text-center text-sm"><?php echo e($item['qty']); ?></span>
                                        <button type="button" data-qty-increase
                                            class="w-8 h-8 text-gray-600 hover:bg-gray-50">+</button>
                                    </div>

                                    <form action="<?php echo e(route('cart.remove', $item['id'])); ?>" method="POST">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-gray-400 hover:text-red-500"><i
                                                class="fa-regular fa-trash-can"></i></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            
            <aside class="border border-gray-100 rounded-lg p-6 h-fit">
                <h2 class="font-semibold text-gray-900 mb-4">Order Summary</h2>
                <div class="space-y-2 text-sm text-gray-600 mb-4">
                    <div class="flex justify-between"><span>Subtotal</span><span
                            data-summary-subtotal>$<?php echo e(number_format($subtotal, 2)); ?></span></div>
                    <?php if($appliedCoupon): ?>
                        <div class="flex justify-between text-emerald-600"><span>Discount
                                (<?php echo e($appliedCoupon); ?>)</span><span
                                data-summary-discount>-$<?php echo e(number_format($discount, 2)); ?></span></div>
                    <?php endif; ?>
                    <div class="flex justify-between"><span>Shipping</span><span>Free</span></div>
                    <div class="flex justify-between"><span>Tax (<?php echo e($taxPct); ?>%)</span><span
                            data-summary-tax>$<?php echo e(number_format($tax, 2)); ?></span></div>
                </div>
                <div class="flex justify-between font-semibold text-gray-900 border-t border-gray-100 pt-4 mb-4">
                    <span>Total</span><span data-summary-total>$<?php echo e(number_format($total, 2)); ?></span>
                </div>

                <div class="flex items-center gap-2 text-sm text-gray-500 mb-3">
                    <i class="fa-solid fa-tag"></i><span>Have a coupon?</span>
                </div>
                <?php if($appliedCoupon): ?>
                    <div
                        class="flex items-center justify-between rounded-md bg-emerald-50 px-3 py-2 mb-5 text-sm text-emerald-700">
                        <span><?php echo e($appliedCoupon); ?> applied</span>
                        <form action="<?php echo e(route('cart.coupon.remove')); ?>" method="POST">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="font-medium hover:underline">Remove</button>
                        </form>
                    </div>
                <?php else: ?>
                    <form action="<?php echo e(route('cart.coupon.apply')); ?>" method="POST" class="flex gap-2 mb-5">
                        <?php echo csrf_field(); ?>
                        <input type="text" name="code" required placeholder="Enter coupon code"
                            class="flex-1 border border-gray-200 rounded-md px-3 py-2 text-sm outline-none">
                        <button type="submit" class="bg-gray-900 text-white text-sm px-4 py-2 rounded-md">Apply</button>
                    </form>
                <?php endif; ?>
                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="mb-5 rounded-md px-4 py-3 text-sm text-red-700">
                        <?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <a href="<?php echo e(route('checkout')); ?>"
                    class="block text-center bg-brand-700 hover:bg-brand-800 text-white py-3 rounded-md font-medium mb-2">Proceed
                    to Checkout</a>
                <a href="<?php echo e(route('shop')); ?>"
                    class="block text-center border border-gray-200 text-gray-700 py-3 rounded-md font-medium hover:bg-gray-50">Continue
                    Shopping</a>
            </aside>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        // Persist quantity changes from the +/- stepper to the server.
        // app.js already listens for clicks on [data-qty-increase/decrease],
        // updates the on-screen count, and fires a bubbling 'qtychange'
        // event with the new value — this just saves that value.
        document.querySelectorAll('[data-cart-row]').forEach(function(row) {
            let saveTimer = null;

            row.addEventListener('qtychange', function(e) {
                const url = row.dataset.updateUrl;
                if (!url) return;

                clearTimeout(saveTimer);
                saveTimer = setTimeout(function() {
                    fetch(url, {
                        method: 'PATCH',
                        headers: {
                            'Content-Type': 'application/json',
                            'Accept': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector(
                                'meta[name="csrf-token"]').content,
                        },
                        body: JSON.stringify({
                            quantity: e.detail.value
                        }),
                    }).catch(function() {
                        // Non-fatal: the visible total is already updated
                        // client-side; a failed save just means a page
                        // refresh would show the previous server value.
                        console.warn('Could not save cart quantity change.');
                    });
                }, 400); // small debounce so rapid +/- clicks send one request
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\user\cart.blade.php ENDPATH**/ ?>