

<?php $__env->startSection('title', 'Payment Cancelled — AgriExpress'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-2xl mx-auto px-4 py-20 text-center">
        <div class="w-16 h-16 mx-auto mb-5 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center">
            <i class="fa-solid fa-arrow-left text-2xl"></i>
        </div>
        <h1 class="text-2xl font-bold text-gray-900 mb-2">Payment cancelled</h1>
        <p class="text-gray-500 mb-8">Your cart is still available. You can return to checkout whenever you are ready.</p>
        <a href="<?php echo e(route('checkout')); ?>"
            class="inline-block bg-brand-700 hover:bg-brand-800 text-white px-5 py-3 rounded-md font-medium">Return to
            checkout</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\checkout-cancel.blade.php ENDPATH**/ ?>