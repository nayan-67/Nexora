<?php $__env->startSection('title', 'Admin Login'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-h-screen flex flex-col">

    <div class="p-6 sm:p-8">
        <a href="<?php echo e(url('/')); ?>" class="text-sm muted hover:text-blue-600 flex items-center gap-2 w-fit">
            <i class="fa-solid fa-arrow-left text-xs"></i>Back to store
        </a>
    </div>

    <div class="flex-1 flex items-center justify-center px-6 pb-16">
        <form action="<?php echo e(route('admin.authenticate')); ?>" method="POST"
              class="w-full" style="max-width: 430px; box-sizing: border-box; padding: 32px; background: #ffffff; border: 1px solid #e5e7eb; border-radius: 18px; box-shadow: 0 20px 45px rgba(15, 23, 42, .10), 0 4px 12px rgba(15, 23, 42, .05);">
            <?php echo csrf_field(); ?>

            <div class="flex flex-col items-center text-center mb-8">
                <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="AgriExpress" class="h-10 w-auto">
                <h1 class="text-xl font-bold mt-6">Admin login</h1>
                <p class="muted text-sm mt-1">Sign in to your admin account</p>
            </div>

            <?php if($errors->any()): ?>
                <div class="mb-5 rounded-xl border border-red-200 bg-red-50 text-red-700 text-[13px] px-4 py-3">
                    <?php echo e($errors->first()); ?>

                </div>
            <?php endif; ?>

            <div class="space-y-4 text-sm">
                <div>
                    <label for="email" class="block font-medium mb-1.5">Email address</label>
                    <div class="flex items-center gap-2.5 border bd rounded-xl px-3.5 h-11">
                        <i class="fa-regular fa-envelope text-slate-400"></i>
                        <input id="email" name="email" type="email" required autofocus
                               class="flex-1 border-0 text-[14px]" placeholder="admin@agriexpress.com"
                               value="<?php echo e(old('email')); ?>">
                    </div>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-[12px] mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label for="password" class="block font-medium mb-1.5">Password</label>
                    <div class="flex items-center gap-2.5 border bd rounded-xl px-3.5 h-11">
                        <i class="fa-solid fa-lock text-slate-400"></i>
                        <input id="password" name="password" type="password" required
                               class="flex-1 border-0 text-[14px]" placeholder="Enter your password">
                        <button type="button" onclick="togglePw()" aria-label="Show password" class="text-slate-400">
                            <i id="pwIcon" class="fa-regular fa-eye"></i>
                        </button>
                    </div>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-[12px] mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="flex items-center justify-between text-[13px]">
                    <label class="flex items-center gap-2 cursor-pointer select-none">
                        <input type="checkbox" name="remember" checked class="w-4 h-4 rounded accent-blue-600">
                        <span class="muted">Remember me</span>
                    </label>
                    <a href="<?php echo e(Route::has('password.request') ? route('password.request') : '#'); ?>" class="text-blue-600 font-medium">Forgot password?</a>
                </div>

                <button type="submit" class="w-full bg-blue-600 hover:bg-blue-500 text-white font-medium rounded-xl h-11 flex items-center justify-center gap-2.5 transition-colors">
                    <i class="fa-solid fa-right-to-bracket"></i> Sign in
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function togglePw(){
    const f = document.getElementById('password');
    const icon = document.getElementById('pwIcon');
    const show = f.type === 'password';
    f.type = show ? 'text' : 'password';
    icon.className = show ? 'fa-regular fa-eye-slash' : 'fa-regular fa-eye';
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\admin\auth\login.blade.php ENDPATH**/ ?>