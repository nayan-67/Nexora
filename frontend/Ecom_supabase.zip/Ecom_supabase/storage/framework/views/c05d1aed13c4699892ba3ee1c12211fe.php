<?php $__env->startSection('title', 'My Account — AgriExpress'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-7xl mx-auto px-4 py-8 grid lg:grid-cols-[240px_1fr] gap-8">
        <?php
            $navBase = 'flex items-center gap-3 px-3 py-2 rounded-md transition-colors';
            $navMuted = $navBase . ' text-gray-600 hover:bg-gray-50';
            $navActive = $navBase . ' bg-brand-50 text-brand-700 font-medium';
            $ordersActive = request()->routeIs('account.orders', 'order.details');
        ?>

        <aside class="border border-gray-100 rounded-lg p-4 h-fit">
            <div class="flex items-center gap-3 px-2 pb-4 mb-4 border-b border-gray-100">
                <span
                    class="w-10 h-10 rounded-full bg-brand-700 text-white flex items-center justify-center font-semibold"><?php echo e($user['initials']); ?></span>
                <div>
                    <p class="font-medium text-gray-900 text-sm"><?php echo e($user['name']); ?></p>
                    <p class="text-xs text-gray-500"><?php echo e($user['email']); ?></p>
                </div>
            </div>
            <nav class="space-y-1 text-sm">
                <a href="<?php echo e(route('account')); ?>" class="<?php echo e(request()->routeIs('account') ? $navActive : $navMuted); ?>"
                    aria-current="<?php echo e(request()->routeIs('account') ? 'page' : 'false'); ?>"><i
                        class="fa-solid fa-gauge w-4"></i> Dashboard</a>
                <a href="<?php echo e(route('account.orders')); ?>" class="<?php echo e($ordersActive ? $navActive : $navMuted); ?>"
                    aria-current="<?php echo e($ordersActive ? 'page' : 'false'); ?>"><i
                        class="fa-solid fa-box w-4"></i> My Orders</a>
                <a href="<?php echo e(route('account.addresses')); ?>" class="<?php echo e(request()->routeIs('account.addresses') ? $navActive : $navMuted); ?>"
                    aria-current="<?php echo e(request()->routeIs('account.addresses') ? 'page' : 'false'); ?>"><i
                        class="fa-solid fa-location-dot w-4"></i> Addresses</a>
                <a href="<?php echo e(route('wishlist')); ?>" class="<?php echo e(request()->routeIs('wishlist') ? $navActive : $navMuted); ?>"
                    aria-current="<?php echo e(request()->routeIs('wishlist') ? 'page' : 'false'); ?>"><i
                        class="fa-regular fa-heart w-4"></i> Wishlist</a>
                <a href="<?php echo e(route('account.profile')); ?>" class="<?php echo e(request()->routeIs('account.profile') ? $navActive : $navMuted); ?>"
                    aria-current="<?php echo e(request()->routeIs('account.profile') ? 'page' : 'false'); ?>"><i
                        class="fa-solid fa-gear w-4"></i> Profile Settings</a>
                <a href="<?php echo e(route('account.profile')); ?>#password" class="<?php echo e(request()->routeIs('account.profile') ? $navActive : $navMuted); ?>"
                    aria-current="<?php echo e(request()->routeIs('account.profile') ? 'page' : 'false'); ?>"><i
                        class="fa-solid fa-key w-4"></i> Change Password</a>
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit"
                        class="w-full flex items-center gap-3 px-3 py-2 rounded-md text-gray-600 hover:bg-gray-50 text-left"><i
                            class="fa-solid fa-arrow-right-from-bracket w-4"></i> Logout</button>
                </form>
            </nav>
        </aside>

        <div>
            <?php if(session('status')): ?>
                <div class="mb-5 rounded-md bg-emerald-50 border border-emerald-200 px-4 py-3 text-sm text-emerald-700"
                    role="status">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">My Account</h1>
                    <p class="text-gray-500 text-sm">Manage your account and orders</p>
                </div>
                <a href="<?php echo e(route('account.profile')); ?>"
                    class="border border-gray-200 rounded-md px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"><i
                        class="fa-solid fa-pen mr-1"></i> Edit Profile</a>
            </div>

            <div class="flex items-center gap-4 border border-gray-100 rounded-lg p-5 mb-6">
                <span
                    class="w-14 h-14 rounded-full bg-brand-700 text-white flex items-center justify-center text-xl font-semibold"><?php echo e($user['initials']); ?></span>
                <div>
                    <p class="font-semibold text-gray-900"><?php echo e($user['name']); ?> <i
                            class="fa-solid fa-circle-check text-emerald-500 text-sm ml-1"></i></p>
                    <p class="text-sm text-gray-500"><?php echo e($user['email']); ?></p>
                </div>
            </div>

            <div class="grid grid-cols-3 gap-4 mb-8">
                <div class="border border-gray-100 rounded-lg p-5 text-center">
                    <p class="text-2xl font-bold text-gray-900"><?php echo e($stats['orders']); ?></p>
                    <p class="text-xs text-gray-500 mt-1">Total Orders</p>
                </div>
                <div class="border border-gray-100 rounded-lg p-5 text-center">
                    <p class="text-2xl font-bold text-gray-900"><?php echo e($stats['wishlist']); ?></p>
                    <p class="text-xs text-gray-500 mt-1">Wishlist Items</p>
                </div>
                <div class="border border-gray-100 rounded-lg p-5 text-center">
                    <p class="text-2xl font-bold text-gray-900"><?php echo e($stats['addresses']); ?></p>
                    <p class="text-xs text-gray-500 mt-1">Addresses</p>
                </div>
            </div>

            <div id="orders" class="flex items-center justify-between mb-4">
                <h2 class="font-semibold text-gray-900"><?php echo e($showAllOrders ? 'My Orders' : 'Recent Orders'); ?></h2>
                <?php if (! ($showAllOrders)): ?>
                    <a href="<?php echo e(route('account.orders')); ?>" class="text-brand-700 text-sm font-medium hover:underline">View All <i
                            class="fa-solid fa-arrow-right text-xs"></i></a>
                <?php endif; ?>
            </div>

            <div class="border border-gray-100 rounded-lg overflow-hidden overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="bg-gray-50 text-gray-500 text-xs uppercase">
                        <tr>
                            <th class="text-left px-4 py-3 font-medium">Order #</th>
                            <th class="text-left px-4 py-3 font-medium">Date</th>
                            <th class="text-left px-4 py-3 font-medium">Status</th>
                            <th class="text-left px-4 py-3 font-medium">Total</th>
                            <th class="text-left px-4 py-3 font-medium">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="px-4 py-3 font-medium text-gray-800">#<?php echo e($order['number']); ?></td>
                                <td class="px-4 py-3 text-gray-500"><?php echo e($order['date']); ?></td>
                                <td class="px-4 py-3"><span
                                        class="<?php echo e($order['status_classes']); ?> text-xs font-medium px-2 py-1 rounded-full"><?php echo e($order['status']); ?></span>
                                </td>
                                <td class="px-4 py-3 text-gray-800">$<?php echo e(number_format($order['total'], 2)); ?></td>
                                <td class="px-4 py-3"><a href="<?php echo e(route('order.details', $order['number'])); ?>"
                                        class="border border-gray-200 rounded-md px-3 py-1 text-xs hover:bg-gray-50">View</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="px-4 py-10 text-center text-sm text-gray-500">
                                    You have not placed any orders yet.
                                    <a href="<?php echo e(route('shop')); ?>" class="text-brand-700 font-medium hover:underline">Start shopping</a>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\user\account.blade.php ENDPATH**/ ?>