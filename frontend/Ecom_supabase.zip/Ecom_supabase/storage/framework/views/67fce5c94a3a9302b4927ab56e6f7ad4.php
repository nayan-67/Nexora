<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['icon' => 'fa-image', 'tone' => 'bg-slate-100 text-slate-600', 'size' => 'w-9 h-9', 'src' => null, 'alt' => '']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['icon' => 'fa-image', 'tone' => 'bg-slate-100 text-slate-600', 'size' => 'w-9 h-9', 'src' => null, 'alt' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php if($src): ?>
    <img src="<?php echo e($src); ?>" alt="<?php echo e($alt); ?>" <?php echo e($attributes->merge(['class' => "$size rounded-lg object-cover shrink-0"])); ?>>
<?php else: ?>
    <span <?php echo e($attributes->merge(['class' => "$size $tone rounded-lg grid place-items-center shrink-0"])); ?>>
        <i class="fa-solid <?php echo e($icon); ?> text-[13px]"></i>
    </span>
<?php endif; ?>
<?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\admin\components\thumb.blade.php ENDPATH**/ ?>