<div class="bg-white rounded-xl p-6 text-left shadow-sm h-full">
    <div class="text-amber-400 text-sm mb-3">
        <?php for($i = 0; $i < 5; $i++): ?>
            <i class="fa-solid fa-star"></i>
        <?php endfor; ?>
    </div>
    <p class="text-gray-600 text-sm mb-4">&ldquo;<?php echo e($t['quote']); ?>&rdquo;</p>
    <div class="flex items-center gap-3">
        <img src="<?php echo e($t['avatar']); ?>" class="w-10 h-10 rounded-full object-cover">
        <div>
            <p class="text-sm font-semibold text-gray-900"><?php echo e($t['name']); ?></p>
            <p class="text-xs text-emerald-600"><i class="fa-solid fa-circle-check"></i> Verified Buyer</p>
        </div>
    </div>
</div>
<?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\user\partials\testimonial-card.blade.php ENDPATH**/ ?>