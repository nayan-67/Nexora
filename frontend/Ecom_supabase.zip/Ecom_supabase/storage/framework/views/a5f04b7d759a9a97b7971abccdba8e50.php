<article
    class="product-card border border-gray-100 rounded-xl overflow-hidden bg-white flex flex-col transition duration-200 group">
    <div class="product-card-image relative h-44 sm:h-48 overflow-hidden bg-gray-50">
        <?php if(!empty($product['badge'])): ?>
            <span
                class="absolute top-3 left-3 z-10 <?php echo e($product['badge_color'] ?? 'bg-brand-700'); ?> text-white text-[10px] font-semibold px-2.5 py-1 rounded-full shadow-sm"><?php echo e($product['badge']); ?></span>
        <?php endif; ?>
        <span class="absolute top-0 right-0 z-10 flex flex-col gap-2 p-2">
            <form action="<?php echo e(auth('web')->check() ? route('wishlist.toggle', $product['id']) : route('login')); ?>"
                method="<?php echo e(auth('web')->check() ? 'POST' : 'GET'); ?>" class="">
                <?php if(auth('web')->check()): ?>
                    <?php echo csrf_field(); ?>
                <?php endif; ?>
                <button type="submit"
                    class="w-9 h-9 rounded-full bg-white/95 shadow-sm flex items-center justify-center text-gray-500 hover:text-rose-500 hover:scale-105 transition"
                    aria-label="Add <?php echo e($product['name']); ?> to wishlist">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                        fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" aria-hidden="true">
                        <path
                            d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78L12 21.23l8.84-8.84a5.5 5.5 0 0 0 0-7.78z" />
                    </svg>
                </button>
            </form>
            <form action="<?php echo e(route('cart.add', $product['id'])); ?>" method="POST" class="">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="quantity" value="1">
                <button type="submit"
                    class="w-9 h-9 rounded-lg bg-gray-100 hover:bg-brand-700 hover:text-white flex items-center justify-center text-gray-600 transition"
                    aria-label="Add <?php echo e($product['name']); ?> to cart" title="Add to cart">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                        fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" class="lucide lucide-shopping-cart-plus preview-icon">
                        <path d="M16 5h6" />
                        <path d="M19 2v6" />
                        <path d="m2.05 2.05 1.099-.028a1 1 0 011.008.815l2.69 14.347A1 1 0 007.83 18H18" />
                        <path d="M4.564 5H12" />
                        <path d="M6.25 14h12.712a2 2 0 001.991-1.57l.172-1.041" />
                        <circle cx="18" cy="20" r="2" />
                        <circle cx="8" cy="20" r="2" />
                    </svg>
                </button>
            </form>

        </span>
        <a href="<?php echo e(route('product', $product['slug'] ?? $product['id'])); ?>"><img src="<?php echo e($product['image']); ?>"
                alt="<?php echo e($product['name']); ?>" loading="lazy"
                class="w-full h-full object-cover transition duration-500 group-hover:scale-105"></a>
    </div>
    <div class="product-card-body flex flex-1 flex-col p-3.5">
        <a href="<?php echo e(route('product', $product['slug'] ?? $product['id'])); ?>" class="block">
            <p class="text-sm font-semibold text-gray-900 truncate group-hover:text-brand-700 transition">
                <?php echo e($product['name']); ?></p>
            <div class="mt-3">
                <?php if (isset($component)) { $__componentOriginalfa87e49ca3cdf62358bbc468aaf3394b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfa87e49ca3cdf62358bbc468aaf3394b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'c44780d405f8ac2435a5fbd03229276a::star-rating','data' => ['rating' => $product['rating'] ?? 5,'count' => $product['reviews'] ?? 0]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('star-rating'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['rating' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product['rating'] ?? 5),'count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product['reviews'] ?? 0)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfa87e49ca3cdf62358bbc468aaf3394b)): ?>
<?php $attributes = $__attributesOriginalfa87e49ca3cdf62358bbc468aaf3394b; ?>
<?php unset($__attributesOriginalfa87e49ca3cdf62358bbc468aaf3394b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfa87e49ca3cdf62358bbc468aaf3394b)): ?>
<?php $component = $__componentOriginalfa87e49ca3cdf62358bbc468aaf3394b; ?>
<?php unset($__componentOriginalfa87e49ca3cdf62358bbc468aaf3394b); ?>
<?php endif; ?>
            </div>
            <div class="flex items-baseline gap-2 mt-2">
                <span class="text-lg font-bold text-gray-900">$<?php echo e(number_format($product['price'], 2)); ?></span>
                <?php if(!empty($product['old_price'])): ?>
                    <span
                        class="text-gray-400 line-through text-xs">$<?php echo e(number_format($product['old_price'], 2)); ?></span>
                <?php endif; ?>
            </div>
        </a>
        <?php if(!empty($product['colors'])): ?>
            <div class="flex items-center gap-2 mt-auto pt-3">
                <div class="flex gap-1.5" aria-label="Available colors">
                    <?php $__currentLoopData = $product['colors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="w-3.5 h-3.5 rounded-full border border-gray-200"
                            style="background-color: <?php echo e(str_starts_with($color, '#') ? $color : '#' . ltrim($color, '#')); ?>"></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</article>
<?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views/user/components/product-card.blade.php ENDPATH**/ ?>