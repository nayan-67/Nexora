<?php $__env->startSection('title', 'Order #' . $order['number'] . ' — AgriExpress'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-5xl mx-auto px-4 py-8">
        <div class="flex items-center justify-between mb-8 flex-wrap gap-2">
            <div>
                <h1 class="text-2xl font-bold text-gray-900">Order Details <span
                        class="text-gray-400 font-normal">#<?php echo e($order['number']); ?></span></h1>
                <p class="text-gray-500 text-sm">Placed on <?php echo e($order['placed_at']); ?> <span class="mx-1">&bull;</span>
                    Delivered on <?php echo e($order['delivered_at']); ?></p>
            </div>
            <a href="<?php echo e(route('account.orders')); ?>" class="text-sm text-brand-700 hover:underline">
                <i class="fa-solid fa-arrow-left mr-1"></i> Back to My Orders
            </a>
        </div>

        
        <div class="flex items-center justify-between mb-10 relative">
            <div class="absolute top-4 left-0 right-0 h-0.5 bg-brand-700 z-0"></div>
            <?php $__currentLoopData = $order['timeline']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex flex-col items-center gap-2 relative z-10 bg-white px-2">
                    <span class="w-8 h-8 rounded-full bg-brand-700 text-white flex items-center justify-center"><i
                            class="fa-solid <?php echo e($step['icon']); ?> text-xs"></i></span>
                    <p class="text-xs font-medium text-gray-800"><?php echo e($step['label']); ?></p>
                    <p class="text-[10px] text-gray-400"><?php echo e($step['date']); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="grid md:grid-cols-[1fr_320px] gap-8">
            <div>
                <h2 class="font-semibold text-gray-900 mb-4">Order Items</h2>
                <div class="divide-y divide-gray-100 border border-gray-100 rounded-lg">
                    <?php $__currentLoopData = $order['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center gap-4 p-4">
                            <img src="<?php echo e($item['image']); ?>" class="w-14 h-14 rounded-md object-cover">
                            <div class="flex-1">
                                <p class="text-sm font-medium text-gray-800"><?php echo e($item['name']); ?></p>
                                <p class="text-xs text-gray-500"><?php echo e($item['variant']); ?></p>
                            </div>
                            <div class="text-right text-sm">
                                <p class="font-medium text-gray-900">$<?php echo e(number_format($item['price'], 2)); ?></p>
                                <p class="text-xs text-gray-400">x<?php echo e($item['qty']); ?></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <aside class="space-y-6">
                <div class="border border-gray-100 rounded-lg p-5">
                    <h3 class="font-semibold text-gray-900 mb-2 text-sm">Shipping Address</h3>
                    <p class="text-sm text-gray-600"><?php echo e($order['address']['name']); ?></p>
                    <p class="text-sm text-gray-600"><?php echo e($order['address']['line1']); ?></p>
                    <p class="text-sm text-gray-600"><?php echo e($order['address']['city']); ?></p>
                    <p class="text-sm text-gray-600"><?php echo e($order['address']['phone']); ?></p>
                </div>
                <?php if($order['billing_address']): ?>
                    <div class="border border-gray-100 rounded-lg p-5">
                        <h3 class="font-semibold text-gray-900 mb-2 text-sm">Billing Address</h3>
                        <p class="text-sm text-gray-600"><?php echo e($order['billing_address']['name']); ?></p>
                        <p class="text-sm text-gray-600"><?php echo e($order['billing_address']['line1']); ?></p>
                        <p class="text-sm text-gray-600"><?php echo e($order['billing_address']['city']); ?></p>
                    </div>
                <?php endif; ?>
                <div class="border border-gray-100 rounded-lg p-5">
                    <h3 class="font-semibold text-gray-900 mb-2 text-sm">Payment Method</h3>
                    <p class="text-sm text-gray-600"><i class="fa-solid fa-credit-card mr-1 text-gray-400"></i>
                        <?php echo e($order['payment_method']); ?></p>
                    <p class="text-xs text-emerald-600 mt-1"><i class="fa-solid fa-circle-check"></i>
                        <?php echo e($order['payment_status']); ?></p>
                </div>
                <div class="border border-gray-100 rounded-lg p-5 text-sm text-gray-600 space-y-2">
                    <div class="flex justify-between"><span>Subtotal</span><span>$<?php echo e(number_format($order['subtotal'], 2)); ?></span></div>
                    <?php if($order['discount'] > 0): ?>
                        <div class="flex justify-between text-emerald-600">
                            <span>Discount<?php echo e($order['coupon_code'] ? ' (' . $order['coupon_code'] . ')' : ''); ?></span>
                            <span>-$<?php echo e(number_format($order['discount'], 2)); ?></span>
                        </div>
                    <?php endif; ?>
                    <div class="flex justify-between"><span>Shipping</span><span><?php echo e($order['shipping'] > 0 ? '$' . number_format($order['shipping'], 2) : 'Free'); ?></span></div>
                    <div class="flex justify-between"><span>Tax</span><span>$<?php echo e(number_format($order['tax'], 2)); ?></span></div>
                    <div class="flex justify-between border-t border-gray-100 pt-3 font-semibold text-gray-900">
                        <span>Total</span><span>$<?php echo e(number_format($order['total'], 2)); ?></span>
                    </div>
                </div>
                <div class="flex gap-3">
                    <button
                        class="flex-1 border border-gray-200 rounded-md py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-50">Track
                        Package</button>
                    <form action="<?php echo e(route('cart.reorder', $order['number'])); ?>" method="POST" class="flex-1">
                        <?php echo csrf_field(); ?>
                        <button type="submit"
                            class="w-full bg-brand-700 hover:bg-brand-800 text-white rounded-md py-2.5 text-sm font-medium">Reorder</button>
                    </form>
                </div>
            </aside>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\user\order-details.blade.php ENDPATH**/ ?>