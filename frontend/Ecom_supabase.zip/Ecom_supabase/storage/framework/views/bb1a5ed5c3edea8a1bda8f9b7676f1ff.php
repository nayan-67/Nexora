
<header class="sticky top-0 z-20 h-17 surface border-b flex items-center gap-4 px-4 sm:px-6">
    <button class="text-slate-500" onclick="toggleSidebar()" aria-label="Open menu">
        <i class="fa-solid fa-bars"></i>
    </button>

    

    <div class="ml-auto flex items-center gap-4">
        

        <button class="text-slate-500 hidden sm:block" onclick="toggleTheme()" title="Switch theme">
            <i class="fa-solid fa-circle-half-stroke text-lg"></i>
        </button>

        <div class="relative">
            <button type="button" onclick="this.nextElementSibling.classList.toggle('hidden')" class="flex items-center gap-2.5">
                <div class="w-9 h-9 rounded-full bg-blue-100 text-blue-700 grid place-items-center font-semibold text-sm">
                    <?php echo e(strtoupper(substr(auth()->user()->name ?? 'Admin', 0, 1))); ?>

                </div>
                <div class="hidden sm:block leading-tight text-left">
                    <p class="text-[13.5px] font-semibold"><?php echo e(auth()->user()->name ?? 'Admin'); ?></p>
                    <p class="text-[11.5px] muted"><?php echo e(auth()->user()->role ?? 'Super Admin'); ?></p>
                </div>
                <i class="fa-solid fa-chevron-down text-[10px] text-slate-400"></i>
            </button>
            <div class="hidden absolute right-0 mt-2 w-44 surface border bd rounded-xl shadow-lg py-1 text-sm z-30">
                <a href="<?php echo e(route('admin.settings.index')); ?>" class="flex items-center gap-2 px-4 py-2 hover:bg-black/5">
                    <i class="fa-solid fa-gear w-4 muted"></i> Settings
                </a>
                <form action="<?php echo e(route('admin.logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="w-full text-left flex items-center gap-2 px-4 py-2 hover:bg-black/5 text-red-500">
                        <i class="fa-solid fa-right-from-bracket w-4"></i> Sign out
                    </button>
                </form>
            </div>
        </div>
    </div>
</header>
<?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\admin\partials\topbar.blade.php ENDPATH**/ ?>