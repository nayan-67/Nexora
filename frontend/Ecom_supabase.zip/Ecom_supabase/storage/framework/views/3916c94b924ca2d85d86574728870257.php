
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
  'eyebrow'  => '',
  'heading'  => '',
  'subtitle' => '',
  'image'    => '',
  'crumbs'   => [],
  'bg'       => 'bg-brand-50',
  'cta'      => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
  'eyebrow'  => '',
  'heading'  => '',
  'subtitle' => '',
  'image'    => '',
  'crumbs'   => [],
  'bg'       => 'bg-brand-50',
  'cta'      => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<section class="relative <?php echo e($bg); ?> overflow-hidden">
  
  <?php if($image): ?>
    <div class="absolute inset-y-0 right-0 w-1/2 hidden md:block">
      <img src="<?php echo e($image); ?>" alt="" class="w-full h-full object-cover">
      <div class="absolute inset-0 bg-linear-to-r <?php echo e(str_replace('bg-', 'from-', $bg)); ?> via-transparent to-transparent"></div>
    </div>
  <?php endif; ?>

  <div class="relative max-w-7xl mx-auto px-4 py-12 md:py-16">
    <div class="max-w-lg">
      <?php if(count($crumbs)): ?>
        <p class="text-xs text-gray-500 mb-3">
          <?php $__currentLoopData = $crumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($url): ?>
              <a href="<?php echo e($url); ?>" class="hover:text-brand-700"><?php echo e($label); ?></a>
              <i class="fa-solid fa-chevron-right text-[8px] mx-1"></i>
            <?php else: ?>
              <span class="text-gray-700"><?php echo e($label); ?></span>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </p>
      <?php endif; ?>

      <?php if($eyebrow): ?>
        <p class="uppercase tracking-wide text-xs font-semibold text-brand-700 mb-3"><?php echo e($eyebrow); ?></p>
      <?php endif; ?>

      <h1 class="text-3xl md:text-4xl font-bold text-gray-900 leading-tight mb-3"><?php echo $heading; ?></h1>

      <?php if($subtitle): ?>
        <p class="text-gray-600 text-sm md:text-base max-w-md"><?php echo e($subtitle); ?></p>
      <?php endif; ?>

      <?php if($cta): ?>
        <a href="<?php echo e($cta['url']); ?>" class="inline-flex items-center gap-2 bg-brand-700 hover:bg-brand-800 text-white px-6 py-3 rounded-md font-medium mt-6">
          <?php echo e($cta['label']); ?> <i class="fa-solid fa-arrow-right text-sm"></i>
        </a>
      <?php endif; ?>
    </div>
  </div>
</section>
<?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\user\components\page-banner.blade.php ENDPATH**/ ?>