<?php $__env->startSection('title', 'Categories'); ?>
<?php $__env->startSection('active', 'categories'); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex flex-wrap gap-3 items-center justify-between mb-5">
        <div>
            <h1 class="text-2xl font-bold">Categories</h1>
            <p class="muted text-sm mt-1">Manage product categories</p>
        </div>
        <a href="<?php echo e(route('admin.categories.create')); ?>"
            class="bg-blue-600 hover:bg-blue-500 text-white rounded-lg px-4 h-10 text-sm font-medium flex items-center"><i
                class="fa-solid fa-plus mr-2"></i>Add category</a>
    </div>

    <div class="surface border rounded-2xl scroll-x">
        <form method="GET" action="<?php echo e(route('admin.categories.index')); ?>" class="p-4 flex flex-wrap gap-3 border-b bd"
            data-admin-filter data-admin-target="categories-results">
            <label class="flex items-center gap-2 flex-1 min-w-55 border bd rounded-lg px-3 h-10">
                <i class="fa-solid fa-magnifying-glass text-slate-400 text-xs"></i>
                <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="flex-1 text-sm border-0"
                    placeholder="Search by name or slug...">
            </label>
            <select name="status" class="border bd rounded-lg px-3 h-10 text-sm">
                <option value="">All status</option>
                <option value="active" <?php if(request('status') === 'active'): echo 'selected'; endif; ?>>Active</option>
                <option value="inactive" <?php if(request('status') === 'inactive'): echo 'selected'; endif; ?>>Inactive</option>
            </select>
            <select name="sort" class="border bd rounded-lg px-3 h-10 text-sm" aria-label="Sort categories">
                <option value="">Display order</option>
                <option value="name_desc" <?php if(request('sort') === 'name_desc'): echo 'selected'; endif; ?>>Name Z-A</option>
                <option value="products" <?php if(request('sort') === 'products'): echo 'selected'; endif; ?>>Most products</option>
            </select>
        </form>
        <div id="categories-results">
            <form id="categories-bulk-form" method="POST" action="<?php echo e(route('admin.categories.bulk-action')); ?>" data-bulk-form
                data-confirm-message="Apply this action to the selected categories?">
                <?php echo csrf_field(); ?>
                <div class="bulk-actions flex flex-wrap items-center gap-3 px-4 py-3 border-b bd">
                    <span class="muted text-sm"><span data-selected-count>0</span> selected</span>
                    <select name="action" required class="border bd rounded-lg px-3 h-9 text-sm">
                        <option value="">Bulk action</option>
                        <option value="activate">Activate</option>
                        <option value="deactivate">Deactivate</option>
                        <option value="delete">Delete</option>
                    </select>
                    <button type="submit" data-bulk-submit disabled
                        class="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg px-3 h-9 text-sm font-medium">
                        Apply
                    </button>
                </div>
            </form>
            <table class="w-full text-sm min-w-190">
                    <thead>
                        <tr class="text-left muted text-[12.5px]" style="background:var(--bg)">
                            <th class="px-4 py-3"><input type="checkbox" onclick="toggleAll(this,'c-check')"></th>
                        <th class="px-4 py-3 font-medium">Image</th>
                        <th class="px-4 py-3 font-medium">Name</th>
                        <th class="px-4 py-3 font-medium">Parent</th>
                        <th class="px-4 py-3 font-medium">Slug</th>
                        <th class="px-4 py-3 font-medium">Products</th>
                        <th class="px-4 py-3 font-medium">Status</th>
                        <th class="px-4 py-3 font-medium">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-b">
                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="px-4 py-3"><input form="categories-bulk-form" type="checkbox" name="selected[]" class="c-check" value="<?php echo e($c->id); ?>"></td>
                            <td class="px-4 py-3"><?php if (isset($component)) { $__componentOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::thumb','data' => ['src' => $c->image_url,'icon' => 'fa-layer-group','size' => 'w-10 h-10']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('thumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c->image_url),'icon' => 'fa-layer-group','size' => 'w-10 h-10']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8)): ?>
<?php $attributes = $__attributesOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8; ?>
<?php unset($__attributesOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8)): ?>
<?php $component = $__componentOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8; ?>
<?php unset($__componentOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8); ?>
<?php endif; ?></td>
                            <td class="px-4 py-3 font-medium"><?php echo e($c->name); ?></td>
                            <td class="px-4 py-3 muted"><?php echo e($c->parent->name ?? '—'); ?></td>
                            <td class="px-4 py-3 muted"><?php echo e($c->slug); ?></td>
                            <td class="px-4 py-3"><?php echo e($c->products_count); ?></td>
                            <td class="px-4 py-3"><?php if (isset($component)) { $__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::pill','data' => ['status' => $c->status ? 'Active' : 'Inactive']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c->status ? 'Active' : 'Inactive')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67)): ?>
<?php $attributes = $__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67; ?>
<?php unset($__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67)): ?>
<?php $component = $__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67; ?>
<?php unset($__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67); ?>
<?php endif; ?></td>
                            <td class="px-4 py-3">
                                <?php if (isset($component)) { $__componentOriginalf9332b595ad3d3a806f9da4dda8769dd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9332b595ad3d3a806f9da4dda8769dd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::action-buttons','data' => ['editRoute' => route('admin.categories.edit', $c),'deleteRoute' => route('admin.categories.destroy', $c)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('action-buttons'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['edit-route' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.categories.edit', $c)),'delete-route' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.categories.destroy', $c))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9332b595ad3d3a806f9da4dda8769dd)): ?>
<?php $attributes = $__attributesOriginalf9332b595ad3d3a806f9da4dda8769dd; ?>
<?php unset($__attributesOriginalf9332b595ad3d3a806f9da4dda8769dd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9332b595ad3d3a806f9da4dda8769dd)): ?>
<?php $component = $__componentOriginalf9332b595ad3d3a806f9da4dda8769dd; ?>
<?php unset($__componentOriginalf9332b595ad3d3a806f9da4dda8769dd); ?>
<?php endif; ?>
                            </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::empty-state','data' => ['colspan' => 8,'message' => 'No categories yet. Create one to start organizing products.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['colspan' => 8,'message' => 'No categories yet. Create one to start organizing products.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
                        <?php endif; ?>
                    </tbody>
            </table>
            <?php if (isset($component)) { $__componentOriginala58819cbc116d88f8edc7af8663d5cf9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala58819cbc116d88f8edc7af8663d5cf9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::pagination-bar','data' => ['paginator' => $categories]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($categories)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala58819cbc116d88f8edc7af8663d5cf9)): ?>
<?php $attributes = $__attributesOriginala58819cbc116d88f8edc7af8663d5cf9; ?>
<?php unset($__attributesOriginala58819cbc116d88f8edc7af8663d5cf9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala58819cbc116d88f8edc7af8663d5cf9)): ?>
<?php $component = $__componentOriginala58819cbc116d88f8edc7af8663d5cf9; ?>
<?php unset($__componentOriginala58819cbc116d88f8edc7af8663d5cf9); ?>
<?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\admin\pages\categories\index.blade.php ENDPATH**/ ?>