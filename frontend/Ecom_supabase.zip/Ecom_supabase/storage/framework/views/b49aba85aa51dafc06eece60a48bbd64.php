<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['rating' => 5, 'count' => 0]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['rating' => 5, 'count' => 0]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<div <?php echo e($attributes->merge(['class' => 'flex items-center gap-1 text-amber-400 text-xs'])); ?>>
  <?php for($i = 1; $i <= 5; $i++): ?>
    <?php if($rating >= $i): ?>
      <i class="fa-solid fa-star"></i>
    <?php elseif($rating > $i - 1): ?>
      <i class="fa-solid fa-star-half-stroke"></i>
    <?php else: ?>
      <i class="fa-regular fa-star"></i>
    <?php endif; ?>
  <?php endfor; ?>
  <?php if($count): ?>
    <span class="text-gray-400 ml-1">(<?php echo e($count); ?>)</span>
  <?php endif; ?>
</div>
<?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\user\components\star-rating.blade.php ENDPATH**/ ?>