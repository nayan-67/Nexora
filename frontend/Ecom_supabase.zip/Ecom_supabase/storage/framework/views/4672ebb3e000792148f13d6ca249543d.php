<div class="bg-brand-800 text-white text-xs">
  <div class="max-w-7xl mx-auto px-4 py-2 flex items-center justify-between">
    <p class="flex items-center gap-2"><i class="fa-solid fa-truck-fast"></i> Free shipping on orders over $50</p>
    <div class="hidden sm:flex items-center gap-5">
      <a href="<?php echo e(url('/track-order')); ?>" class="hover:text-brand-100">Track Order</a>
      <a href="<?php echo e(url('/help')); ?>" class="hover:text-brand-100">Help</a>
      <a href="<?php echo e(url('/contact')); ?>" class="hover:text-brand-100">Contact</a>
    </div>
  </div>
</div>
<?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views/user/partials/topbar.blade.php ENDPATH**/ ?>