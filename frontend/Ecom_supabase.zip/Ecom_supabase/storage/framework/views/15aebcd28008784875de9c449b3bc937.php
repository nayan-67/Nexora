
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['label', 'value', 'change', 'icon', 'tone' => 'bg-blue-50', 'iconBg' => 'bg-blue-500', 'lineColor' => '#3b82f6']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['label', 'value', 'change', 'icon', 'tone' => 'bg-blue-50', 'iconBg' => 'bg-blue-500', 'lineColor' => '#3b82f6']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<div class="rounded-2xl p-5 border <?php echo e($tone); ?>" style="border-color:rgba(0,0,0,.05)">
    <div class="flex items-start gap-3">
        <span class="w-11 h-11 rounded-xl <?php echo e($iconBg); ?> text-white grid place-items-center shrink-0">
            <i class="fa-solid <?php echo e($icon); ?>"></i>
        </span>
        <div class="min-w-0">
            <p class="text-[13px] text-slate-600"><?php echo e($label); ?></p>
            <p class="text-[22px] font-bold text-slate-900 mt-0.5"><?php echo e($value); ?></p>
        </div>
    </div>
    <div class="flex items-end justify-between mt-3">
        <p class="text-[12.5px]">
            <span class="text-emerald-600 font-semibold"><i class="fa-solid fa-arrow-up text-[10px]"></i> <?php echo e($change); ?></span>
            <span class="text-slate-500">vs last week</span>
        </p>
        <svg viewBox="0 0 88 22" class="w-[86px] h-[26px]" aria-hidden="true">
            <polyline points="0,18 14,14 28,16 42,10 56,12 70,6 84,3" fill="none" stroke="<?php echo e($lineColor); ?>" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
    </div>
</div>
<?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\admin\components\stat-card.blade.php ENDPATH**/ ?>