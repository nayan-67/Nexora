<?php $__env->startSection('title', 'Products'); ?>
<?php $__env->startSection('active', 'products'); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex flex-wrap gap-3 items-center justify-between mb-5">
        <div>
            <h1 class="text-2xl font-bold">Products</h1>
            <p class="muted text-sm mt-1">Manage your store products</p>
        </div>
        <div class="flex gap-2">
            <button class="surface border rounded-lg px-4 h-10 text-sm"><i
                    class="fa-solid fa-file-import mr-2 muted"></i>Import</button>
            <button class="surface border rounded-lg px-4 h-10 text-sm"><i
                    class="fa-solid fa-file-export mr-2 muted"></i>Export</button>
            <a href="<?php echo e(route('admin.products.create')); ?>"
                class="bg-blue-600 hover:bg-blue-500 text-white rounded-lg px-4 h-10 text-sm font-medium flex items-center"><i
                    class="fa-solid fa-plus mr-2"></i>Add product</a>
        </div>
    </div>

    <div class="surface border rounded-2xl">
        <form method="GET" action="<?php echo e(route('admin.products.index')); ?>" class="p-4 flex flex-wrap gap-3 border-b bd"
            data-admin-filter data-admin-target="products-results">
            <label class="flex items-center gap-2 flex-1 min-w-55 border bd rounded-lg px-3 h-10">
                <i class="fa-solid fa-magnifying-glass text-slate-400 text-xs"></i>
                <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="flex-1 text-sm border-0"
                    placeholder="Search by name, SKU...">
            </label>
            <select name="category" class="border bd rounded-lg px-3 h-10 text-sm">
                <option value="">All categories</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($c->slug); ?>" <?php if(request('category') === $c->slug): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <select name="status" class="border bd rounded-lg px-3 h-10 text-sm">
                <option value="">All status</option>
                <option value="published" <?php if(request('status') === 'published'): echo 'selected'; endif; ?>>Published</option>
                <option value="draft" <?php if(request('status') === 'draft'): echo 'selected'; endif; ?>>Draft</option>
            </select>
            <select name="sort" class="border bd rounded-lg px-3 h-10 text-sm" aria-label="Sort products">
                <option value="">Newest</option>
                <option value="name" <?php if(request('sort') === 'name'): echo 'selected'; endif; ?>>Name A-Z</option>
                <option value="price_asc" <?php if(request('sort') === 'price_asc'): echo 'selected'; endif; ?>>Price low to high</option>
                <option value="price_desc" <?php if(request('sort') === 'price_desc'): echo 'selected'; endif; ?>>Price high to low</option>
            </select>
        </form>

        <div id="products-results">
            <form id="products-bulk-form" method="POST" action="<?php echo e(route('admin.products.bulk-action')); ?>" data-bulk-form
                data-confirm-message="Apply this action to the selected products?">
                <?php echo csrf_field(); ?>
                <div class="bulk-actions flex flex-wrap items-center gap-3 px-4 py-3 border-b bd">
                    <span class="muted text-sm"><span data-selected-count>0</span> selected</span>
                    <select name="action" required class="border bd rounded-lg px-3 h-9 text-sm">
                        <option value="">Bulk action</option>
                        <option value="activate">Activate</option>
                        <option value="deactivate">Deactivate</option>
                        <option value="delete">Delete</option>
                    </select>
                    <button type="submit" data-bulk-submit disabled
                        class="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg px-3 h-9 text-sm font-medium">
                        Apply
                    </button>
                </div>
            </form>
            <div class="scroll-x">
                <table class="w-full text-sm min-w-215">
                    <thead>
                        <tr class="text-left muted text-[12.5px]" style="background:var(--bg)">
                            <th class="px-4 py-3"><input type="checkbox" onclick="toggleAll(this,'p-check')"></th>
                            <th class="px-4 py-3 font-medium">Image</th>
                            <th class="px-4 py-3 font-medium">Name</th>
                            <th class="px-4 py-3 font-medium">Category</th>
                            <th class="px-4 py-3 font-medium">Price</th>
                            <th class="px-4 py-3 font-medium">Stock</th>
                            <th class="px-4 py-3 font-medium">Status</th>
                            <th class="px-4 py-3 font-medium">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-b">
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="px-4 py-3"><input form="products-bulk-form" type="checkbox" name="selected[]" class="p-check"
                                        value="<?php echo e($p->id); ?>">
                                </td>
                                <td class="px-4 py-3"><?php if (isset($component)) { $__componentOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::thumb','data' => ['src' => $p->main_image_url,'icon' => 'fa-box','size' => 'w-10 h-10']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('thumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($p->main_image_url),'icon' => 'fa-box','size' => 'w-10 h-10']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8)): ?>
<?php $attributes = $__attributesOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8; ?>
<?php unset($__attributesOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8)): ?>
<?php $component = $__componentOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8; ?>
<?php unset($__componentOriginalc5e0a6882bf9cfec04b1f8f40deb1aa8); ?>
<?php endif; ?></td>
                                <td class="px-4 py-3 font-medium"><?php echo e($p->name); ?><span
                                        class="block muted text-[11.5px] font-normal"><?php echo e($p->sku); ?></span></td>
                                <td class="px-4 py-3 text-blue-600"><?php echo e($p->category->name ?? '—'); ?></td>
                                <td class="px-4 py-3 font-medium">
                                    $<?php echo e(number_format($p->sale_price ?? $p->price, 2)); ?>

                                    <?php if($p->sale_price): ?>
                                        <span
                                            class="block muted text-[11.5px] line-through font-normal">$<?php echo e(number_format($p->price, 2)); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-3 muted"><?php echo e($p->stock); ?></td>
                                <td class="px-4 py-3"><?php if (isset($component)) { $__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::pill','data' => ['status' => $p->status ? 'Published' : 'Draft']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($p->status ? 'Published' : 'Draft')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67)): ?>
<?php $attributes = $__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67; ?>
<?php unset($__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67)): ?>
<?php $component = $__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67; ?>
<?php unset($__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67); ?>
<?php endif; ?></td>
                                <td class="px-4 py-3">
                                    <?php if (isset($component)) { $__componentOriginalf9332b595ad3d3a806f9da4dda8769dd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9332b595ad3d3a806f9da4dda8769dd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::action-buttons','data' => ['editRoute' => route('admin.products.edit', $p),'deleteRoute' => route('admin.products.destroy', $p)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('action-buttons'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['edit-route' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.products.edit', $p)),'delete-route' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.products.destroy', $p))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9332b595ad3d3a806f9da4dda8769dd)): ?>
<?php $attributes = $__attributesOriginalf9332b595ad3d3a806f9da4dda8769dd; ?>
<?php unset($__attributesOriginalf9332b595ad3d3a806f9da4dda8769dd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9332b595ad3d3a806f9da4dda8769dd)): ?>
<?php $component = $__componentOriginalf9332b595ad3d3a806f9da4dda8769dd; ?>
<?php unset($__componentOriginalf9332b595ad3d3a806f9da4dda8769dd); ?>
<?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::empty-state','data' => ['colspan' => 8,'message' => 'No products match this search. Try a different name or clear the filters.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['colspan' => 8,'message' => 'No products match this search. Try a different name or clear the filters.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if (isset($component)) { $__componentOriginala58819cbc116d88f8edc7af8663d5cf9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala58819cbc116d88f8edc7af8663d5cf9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::pagination-bar','data' => ['paginator' => $products]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($products)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala58819cbc116d88f8edc7af8663d5cf9)): ?>
<?php $attributes = $__attributesOriginala58819cbc116d88f8edc7af8663d5cf9; ?>
<?php unset($__attributesOriginala58819cbc116d88f8edc7af8663d5cf9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala58819cbc116d88f8edc7af8663d5cf9)): ?>
<?php $component = $__componentOriginala58819cbc116d88f8edc7af8663d5cf9; ?>
<?php unset($__componentOriginala58819cbc116d88f8edc7af8663d5cf9); ?>
<?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\admin\pages\products\index.blade.php ENDPATH**/ ?>