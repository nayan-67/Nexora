<?php $__env->startSection('title', 'Orders'); ?>
<?php $__env->startSection('active', 'orders'); ?>

<?php $activeTab = request('status', 'All'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex flex-wrap gap-3 items-center justify-between mb-5">
    <div><h1 class="text-2xl font-bold">Orders</h1><p class="muted text-sm mt-1">Manage customer orders</p></div>
    <button class="surface border rounded-lg px-4 h-10 text-sm"><i class="fa-solid fa-file-export mr-2 muted"></i>Export</button>
</div>

<div class="surface border rounded-2xl">
    <div class="flex gap-6 px-5 border-b bd overflow-x-auto text-sm">
        <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('admin.orders.index', ['status' => $label])); ?>"
               class="py-3.5 font-medium border-b-2 whitespace-nowrap <?php echo e($activeTab === $label ? 'border-blue-600 text-blue-600' : 'border-transparent muted'); ?>">
                <?php echo e($label); ?> (<?php echo e($count); ?>)
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <form method="GET" action="<?php echo e(route('admin.orders.index')); ?>" class="p-4 flex flex-wrap gap-3">
        <input type="hidden" name="status" value="<?php echo e($activeTab); ?>">
        <label class="flex items-center gap-2 flex-1 min-w-55 border bd rounded-lg px-3 h-10">
            <i class="fa-solid fa-magnifying-glass text-slate-400 text-xs"></i>
            <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="flex-1 text-sm border-0" placeholder="Search by order number, customer...">
        </label>
        <button type="submit" class="border bd rounded-lg px-4 h-10 text-sm"><i class="fa-solid fa-filter mr-2 muted"></i>Filter</button>
    </form>

    <div class="scroll-x">
        <table class="w-full text-sm min-w-200">
            <thead><tr class="text-left muted text-[12.5px]" style="background:var(--bg)">
                <th class="px-5 py-3 font-medium">Order number</th>
                <th class="px-5 py-3 font-medium">Customer</th><th class="px-5 py-3 font-medium">Total</th>
                <th class="px-5 py-3 font-medium">Status</th><th class="px-5 py-3 font-medium">Payment</th>
                <th class="px-5 py-3 font-medium">Date</th><th class="px-5 py-3 font-medium">Action</th>
            </tr></thead>
            <tbody class="divide-b">
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="px-5 py-3.5 font-medium"><?php echo e($o->order_number); ?></td>
                        <td class="px-5 py-3.5"><span class="flex items-center gap-2.5"><?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::avatar','data' => ['name' => $o->user->name ?? 'Guest','index' => $i]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($o->user->name ?? 'Guest'),'index' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($i)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?><?php echo e($o->user->name ?? 'Guest checkout'); ?></span></td>
                        <td class="px-5 py-3.5 font-medium">$<?php echo e(number_format($o->total_price, 2)); ?></td>
                        <td class="px-5 py-3.5"><?php if (isset($component)) { $__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::pill','data' => ['status' => $o->order_status_label]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($o->order_status_label)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67)): ?>
<?php $attributes = $__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67; ?>
<?php unset($__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67)): ?>
<?php $component = $__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67; ?>
<?php unset($__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67); ?>
<?php endif; ?></td>
                        <td class="px-5 py-3.5"><?php if (isset($component)) { $__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::pill','data' => ['status' => $o->payment_status_label]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($o->payment_status_label)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67)): ?>
<?php $attributes = $__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67; ?>
<?php unset($__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67)): ?>
<?php $component = $__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67; ?>
<?php unset($__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67); ?>
<?php endif; ?></td>
                        <td class="px-5 py-3.5 muted"><?php echo e($o->created_at->format('M j, Y')); ?></td>
                        <td class="px-5 py-3.5"><a href="<?php echo e(route('admin.orders.show', $o)); ?>" class="border bd rounded-lg px-3 py-1.5 text-[12.5px] text-blue-600 font-medium">View</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::empty-state','data' => ['colspan' => 7,'message' => 'No orders here yet. Change the filter to see more.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['colspan' => 7,'message' => 'No orders here yet. Change the filter to see more.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if (isset($component)) { $__componentOriginala58819cbc116d88f8edc7af8663d5cf9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala58819cbc116d88f8edc7af8663d5cf9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::pagination-bar','data' => ['paginator' => $orders]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($orders)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala58819cbc116d88f8edc7af8663d5cf9)): ?>
<?php $attributes = $__attributesOriginala58819cbc116d88f8edc7af8663d5cf9; ?>
<?php unset($__attributesOriginala58819cbc116d88f8edc7af8663d5cf9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala58819cbc116d88f8edc7af8663d5cf9)): ?>
<?php $component = $__componentOriginala58819cbc116d88f8edc7af8663d5cf9; ?>
<?php unset($__componentOriginala58819cbc116d88f8edc7af8663d5cf9); ?>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\admin\pages\orders\index.blade.php ENDPATH**/ ?>