<?php $__env->startSection('title', $customer->name); ?>
<?php $__env->startSection('active', 'customers'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex flex-wrap gap-3 items-center justify-between mb-5">
    <div>
        <h1 class="text-2xl font-bold"><?php echo e($customer->name); ?></h1>
        <p class="text-sm mt-1">
            <a href="<?php echo e(route('admin.customers.index')); ?>" class="text-blue-600">Customers</a>
            <i class="fa-solid fa-chevron-right text-[9px] muted mx-1"></i>
            <span class="muted"><?php echo e($customer->name); ?></span>
        </p>
    </div>
    <form action="<?php echo e(route('admin.customers.updateStatus', $customer)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <input type="hidden" name="status" value="<?php echo e($customer->status ? 0 : 1); ?>">
        <button type="submit" class="border bd rounded-lg px-4 h-10 text-sm font-medium <?php echo e($customer->status ? 'text-red-500' : 'text-emerald-600'); ?>">
            <?php echo e($customer->status ? 'Block customer' : 'Unblock customer'); ?>

        </button>
    </form>
</div>

<div class="grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-5">
    <div class="surface border rounded-2xl p-5 space-y-5 h-fit">
        <div class="flex items-center gap-3">
            <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::avatar','data' => ['name' => $customer->name,'class' => 'w-14 h-14 text-lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($customer->name),'class' => 'w-14 h-14 text-lg']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
            <div>
                <p class="font-semibold"><?php echo e($customer->name); ?></p>
                <?php if (isset($component)) { $__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::pill','data' => ['status' => $customer->status_label]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($customer->status_label)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67)): ?>
<?php $attributes = $__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67; ?>
<?php unset($__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67)): ?>
<?php $component = $__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67; ?>
<?php unset($__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67); ?>
<?php endif; ?>
            </div>
        </div>
        <div class="pt-4 border-t bd text-sm space-y-2">
            <p class="flex items-center gap-2"><i class="fa-regular fa-envelope w-4 muted"></i><?php echo e($customer->email); ?></p>
            <p class="flex items-center gap-2"><i class="fa-solid fa-phone w-4 muted"></i><?php echo e($customer->phone ?? '—'); ?></p>
            <p class="flex items-center gap-2"><i class="fa-regular fa-calendar w-4 muted"></i>Joined <?php echo e($customer->created_at->format('M d, Y')); ?></p>
        </div>

        <?php if($customer->addresses->isNotEmpty()): ?>
            <div class="pt-4 border-t bd text-sm">
                <p class="font-medium mb-2">Saved addresses</p>
                <div class="space-y-3">
                    <?php $__currentLoopData = $customer->addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="text-[13px] muted leading-relaxed">
                            <span class="text-[11px] font-semibold uppercase text-blue-600"><?php echo e($address->type); ?><?php echo e($address->is_default ? ' · Default' : ''); ?></span><br>
                            <?php echo e($address->first_name); ?> <?php echo e($address->last_name); ?><br>
                            <?php echo e($address->address_line_1); ?><?php echo e($address->address_line_2 ? ', '.$address->address_line_2 : ''); ?><br>
                            <?php echo e($address->city); ?>, <?php echo e($address->state); ?> <?php echo e($address->postal_code); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div class="surface border rounded-2xl">
        <div class="p-5 pb-3"><h2 class="font-semibold">Recent orders</h2></div>
        <div class="scroll-x">
            <table class="w-full text-sm min-w-[640px]">
                <thead><tr class="text-left muted text-[12.5px]" style="background:var(--bg)">
                    <th class="px-5 py-3 font-medium">Order</th><th class="px-5 py-3 font-medium">Total</th>
                    <th class="px-5 py-3 font-medium">Status</th><th class="px-5 py-3 font-medium">Date</th>
                    <th class="px-5 py-3 font-medium">Action</th>
                </tr></thead>
                <tbody class="divide-b">
                    <?php $__empty_1 = true; $__currentLoopData = $customer->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="px-5 py-3.5 font-medium"><?php echo e($order->order_number); ?></td>
                            <td class="px-5 py-3.5 font-medium">$<?php echo e(number_format($order->total_price, 2)); ?></td>
                            <td class="px-5 py-3.5"><?php if (isset($component)) { $__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::pill','data' => ['status' => $order->order_status_label]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->order_status_label)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67)): ?>
<?php $attributes = $__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67; ?>
<?php unset($__attributesOriginalba50127835a1acb6a4b9a6fac0dd3a67); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67)): ?>
<?php $component = $__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67; ?>
<?php unset($__componentOriginalba50127835a1acb6a4b9a6fac0dd3a67); ?>
<?php endif; ?></td>
                            <td class="px-5 py-3.5 muted"><?php echo e($order->created_at->format('M d, Y')); ?></td>
                            <td class="px-5 py-3.5"><a href="<?php echo e(route('admin.orders.show', $order)); ?>" class="border bd rounded-lg px-3 py-1.5 text-[12.5px] text-blue-600 font-medium">View</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '18bacc1a6282b846bec6b7ec366a2e43::empty-state','data' => ['colspan' => 5,'message' => 'This customer hasn\'t placed any orders yet.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['colspan' => 5,'message' => 'This customer hasn\'t placed any orders yet.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\admin\pages\customers\show.blade.php ENDPATH**/ ?>