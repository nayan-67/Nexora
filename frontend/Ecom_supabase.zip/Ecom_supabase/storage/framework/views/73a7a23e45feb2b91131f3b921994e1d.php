<?php $__env->startSection('title', 'About Us — AgriExpress'); ?>

<?php $__env->startSection('content'); ?>

    <?php if (isset($component)) { $__componentOriginalb00c7f6baf7ea834a0251f4153d10b8b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb00c7f6baf7ea834a0251f4153d10b8b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'c44780d405f8ac2435a5fbd03229276a::page-banner','data' => ['eyebrow' => 'About Us','heading' => 'Our Story<br>Your Trusted Store','subtitle' => 'At AgriExpress, we believe that great products bring happiness to everyday life. We\'re more than just an online store — we\'re a community that values quality, style and your satisfaction.','image' => 'https://images.unsplash.com/photo-1567016432779-094069958ea5?w=1000&q=80','crumbs' => ['Home' => route('index'), 'About Us' => null],'cta' => ['label' => 'Shop Now', 'url' => route('shop')]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['eyebrow' => 'About Us','heading' => 'Our Story<br>Your Trusted Store','subtitle' => 'At AgriExpress, we believe that great products bring happiness to everyday life. We\'re more than just an online store — we\'re a community that values quality, style and your satisfaction.','image' => 'https://images.unsplash.com/photo-1567016432779-094069958ea5?w=1000&q=80','crumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['Home' => route('index'), 'About Us' => null]),'cta' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['label' => 'Shop Now', 'url' => route('shop')])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb00c7f6baf7ea834a0251f4153d10b8b)): ?>
<?php $attributes = $__attributesOriginalb00c7f6baf7ea834a0251f4153d10b8b; ?>
<?php unset($__attributesOriginalb00c7f6baf7ea834a0251f4153d10b8b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb00c7f6baf7ea834a0251f4153d10b8b)): ?>
<?php $component = $__componentOriginalb00c7f6baf7ea834a0251f4153d10b8b; ?>
<?php unset($__componentOriginalb00c7f6baf7ea834a0251f4153d10b8b); ?>
<?php endif; ?>

    
    <section class="max-w-7xl mx-auto px-4 py-12">
        <div class="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <?php $__currentLoopData = $valueProps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex flex-col items-center gap-3">
                    <span class="w-14 h-14 rounded-full bg-brand-50 flex items-center justify-center text-brand-700 text-xl">
                        <i class="<?php echo e($prop['icon']); ?>"></i>
                    </span>
                    <div>
                        <p class="font-semibold text-gray-900 text-sm"><?php echo e($prop['title']); ?></p>
                        <p class="text-xs text-gray-500 mt-1"><?php echo e($prop['subtitle']); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

    
    <section class="max-w-7xl mx-auto px-4 pb-12">
        <div class="grid md:grid-cols-2 gap-10 items-center">
            <div class="relative rounded-xl overflow-hidden">
                <img src="<?php echo e($mission['image']); ?>" alt="Our mission" class="w-full h-80 object-cover rounded-xl">
                <div class="absolute bottom-5 left-5 bg-white rounded-lg shadow-md px-4 py-3 flex items-center gap-2">
                    <span class="text-rose-500"><i class="fa-solid fa-heart"></i></span>
                    <div>
                        <p class="text-sm font-semibold text-gray-900 leading-none">Better</p>
                        <p class="text-sm font-semibold text-gray-900 leading-none">Products</p>
                        <p class="text-sm font-semibold text-gray-900 leading-none">Happier You</p>
                    </div>
                </div>
            </div>
            <div>
                <p class="uppercase tracking-wide text-xs font-semibold text-brand-700 mb-3">Our Mission</p>
                <h2 class="text-3xl font-bold text-gray-900 leading-tight mb-4"><?php echo $mission['heading']; ?></h2>
                <p class="text-gray-600 text-sm leading-relaxed mb-8"><?php echo e($mission['body']); ?></p>

                <div class="grid grid-cols-3 gap-6 border-t border-gray-100 pt-6">
                    <?php $__currentLoopData = $mission['stats']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>
                            <p class="text-2xl font-bold text-gray-900">
                                <?php echo e($stat['value']); ?><?php if(!empty($stat['star'])): ?>
                                    <i class="fa-solid fa-star text-amber-400 text-lg ml-1"></i>
                                <?php endif; ?>
                            </p>
                            <p class="text-xs text-gray-500 mt-1"><?php echo e($stat['label']); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>

    
    <section class="bg-brand-50 py-14">
        <div class="max-w-7xl mx-auto px-4">
            <p class="uppercase tracking-wide text-xs font-semibold text-brand-700 mb-2">Why Choose Us</p>
            <h2 class="text-2xl md:text-3xl font-bold text-gray-900 mb-10">What Makes Us Different</h2>

            <div class="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
                <?php $__currentLoopData = $differentiators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex flex-col items-center gap-3">
                        <span
                            class="w-14 h-14 rounded-full bg-white flex items-center justify-center text-brand-700 text-xl shadow-sm">
                            <i class="<?php echo e($item['icon']); ?>"></i>
                        </span>
                        <div>
                            <p class="font-semibold text-gray-900 text-sm"><?php echo e($item['title']); ?></p>
                            <p class="text-xs text-gray-500 mt-1 max-w-48 mx-auto"><?php echo e($item['subtitle']); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\personal\Laravel\Ecom_supabase\resources\views\user\about.blade.php ENDPATH**/ ?>